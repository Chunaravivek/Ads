<?php
App::uses('AppModel', 'Model');

class Cities extends AppModel 
{
    public $name = 'Cities';
    public $useTable = 'cities';
    public $primaryKey  = 'id';
    public $displayField = 'name';
    
    function all() {
        $model = $this;
        return Cache::remember('all_cities', function () use ($model){
         
            return $model->find('all');
        });
    }
}