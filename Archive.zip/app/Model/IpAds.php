<?php
App::uses('AppModel', 'Model');

class IpAds extends AppModel 
{
    public $name = 'IpAds';
    public $useTable = 'ipwise_adid';
    public $primaryKey  = 'id';
    public $displayField = 'app_code';
    
    public $belongsTo = array(
        'Accounts' => array(
            'className' => 'Accounts',
            'foreignKey' => 'acc_id',
        ),
        'Applications' => array(
            'className' => 'Applications',
            'foreignKey' => 'acc_id',
        ),
        'Cities' => array(
            'className' => 'Cities',
            'foreignKey' => 'city_id',
        ),
    );
    
    function all() {
        $model = $this;
        return Cache::remember('all_ipwise_adid', function () use ($model){
         
            return $model->find('all');
        });
    }
}