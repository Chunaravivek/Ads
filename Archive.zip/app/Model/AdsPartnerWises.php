<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppModel', 'Model');

/**
 * CakePHP AdsPartnerWises
 * @author s4
 */
class AdsPartnerWises extends AppModel {
    public $name        = 'AdsPartnerWises';
    public $useTable    = 'ads_partner_wises';
    public $primaryKey  = 'id';
    public $displayField = 'ad_partner';
    public $belongsTo = array(
        'Accounts' => array(
            'className' => 'Accounts',
            'foreignKey' => 'acc_id'
        ),
        'Applications' => array(
            'className' => 'Applications',
            'foreignKey' => 'acc_id'
        ),
        'AdPartner' => array(
            'className' => 'AdPartner',
            'foreignKey' => 'ad_partner'
        ),
    );
    
}
