<?php
App::uses('AppModel', 'Model');

class Applications extends AppModel 
{
    public $name = 'Applications';
    public $useTable = 'applications';
    public $primaryKey  = 'id';
    public $displayField = 'app_code';
    
    public $belongsTo = array(
        'Accounts' => array(
            'className' => 'Accounts',
            'foreignKey' => 'account_id',
        ),
    );
    
    function all() {
        $model = $this;
        return Cache::remember('all_applications', function () use ($model){
         
            return $model->find('all');
        });
    }
}