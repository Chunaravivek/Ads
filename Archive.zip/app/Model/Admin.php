<?php
App::uses('AppModel', 'Model');

class Admin extends AppModel 
{
    public $name = 'Admin';
    public $useTable = 'admins';
    public $primaryKey  = 'id';
}