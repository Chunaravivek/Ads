<?php
App::uses('AppModel', 'Model');

class AdIds extends AppModel 
{
    public $name = 'AdIds';
    public $useTable = 'ad_ids';
    public $primaryKey  = 'id';
    public $displayField = 'app_code';
    
    public $belongsTo = array(
        'Accounts' => array(
            'className' => 'Accounts',
            'foreignKey' => 'acc_id',
        ),
        'Applications' => array(
            'className' => 'Applications',
            'foreignKey' => 'app_code',
        ),
    );
    
    function all() {
        $model = $this;
        return Cache::remember('all_applications', function () use ($model){
         
            return $model->find('all');
        });
    }
}