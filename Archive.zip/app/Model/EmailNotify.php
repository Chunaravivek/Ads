<?php
App::uses('AppModel', 'Model');

class EmailNotify extends AppModel 
{
    public $name = 'EmailNotify';
    public $useTable = 'email_notify';
    public $primaryKey  = 'id';
    public $displayField = 'email';
    
    function all() {
        $model = $this;
        return Cache::remember('all_email_notify', function () use ($model){
         
            return $model->find('all');
        });
    }
}