<?php
App::uses('AppModel', 'Model');

class AdPartner extends AppModel 
{
    public $name = 'AdPartner';
    public $useTable = 'ad_partner';
    public $primaryKey  = 'id';
    public $displayField = 'name';
    
    function all() {
        $model = $this;
        return Cache::remember('all_ad_partner', function () use ($model){
         
            return $model->find('all');
        });
    }
}