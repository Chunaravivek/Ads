<?php
App::uses('AppModel', 'Model');

class Accounts extends AppModel 
{
    public $name = 'Accounts';
    public $useTable = 'accounts';
    public $primaryKey  = 'id';
    public $displayField = 'name';
    
    function all() {
        $model = $this;
        return Cache::remember('all_accounts', function () use ($model){
         
            return $model->find('all');
        });
    }
}