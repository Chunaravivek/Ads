
<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

class AdPartnerController extends AppController {

    public $uses = array('AdPartner');

    public function index() {
        $description = 'Manage AdPartner';
        $keywords = 'Manage AdPartner';
        $this->set(compact('keywords', 'description'));
    }

    public function records() {
        if (isset($this->request->query['sidx']) && $this->request->query['sidx'] != NULL)
            $order = "AdPartner." . $this->request->query['sidx'] . " " . $this->request->query['sord'] . "";
        else {
            $order = "AdPartner.modified_date DESC";
        }

        $conditions = '1=1 ';

        if (isset($this->request->query['filters']) && $this->request->query['filters'] != '') {
            $filters = json_decode($this->request->query['filters']);
            $conditions = '';
            foreach ($filters->rules as $filter) {
                if ($filter->op == 'eq') {
                    $conditions .= "`AdPartner." . $filter->field . "` = '$filter->data' AND ";
                } elseif ($filter->op == 'ne') {
                    $conditions .= "`AdPartner." . $filter->field . "` !='$filter->data' AND ";
                } elseif ($filter->op == 'bw') {
                    $conditions .= "`AdPartner." . $filter->field . "` Like '$filter->data%' AND ";
                } elseif ($filter->op == 'bn') {
                    $conditions .= "`AdPartner." . $filter->field . "` NOT Like '$filter->data%' AND ";
                } elseif ($filter->op == 'ew') {
                    $conditions .= "`AdPartner." . $filter->field . "` Like '%$filter->data' AND ";
                } elseif ($filter->op == 'en') {
                    $conditions .= "`AdPartner." . $filter->field . "` NOT Like '%$filter->data' AND ";
                } elseif ($filter->op == 'cn') {
                    $conditions .= "`AdPartner." . $filter->field . "` Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'nc') {
                    $conditions .= "`AdPartner." . $filter->field . "` NOT Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'in') {
                    $conditions .= "`AdPartner." . $filter->field . "` IN ($filter->data) AND ";
                } elseif ($filter->op == 'ni') {
                    $conditions .= "`AdPartner." . $filter->field . "` NOT IN ($filter->data) AND ";
                }
            }
        }

        $i = 0;
        $result = array();

        if (isset($this->request->query['page']) && $this->request->query['page'] != '') {
            $result['page'] = (int) $this->request->query['page'];
        } else {
            $result['page'] = 1;
        }

        $conditions = substr($conditions, 0, -4);

        if (isset($this->request->query['rows']) && $this->request->query['rows'] != '') {
            $limit = (int) $this->request->query['rows'];
        } else {
            $limit = 10;
        }

        $offset = ($result['page'] - 1) * $limit;

        $keys = $this->AdPartner->find('all', array('conditions' => array($conditions), 'order' => $order, 'limit' => $limit, 'offset' => $offset));

        $counts = $this->AdPartner->find('count', array('conditions' => array($conditions), 'order' => $order));

        if ($counts > 0) {
            $result['total'] = ceil($counts / $limit);
        } else {
            $result['total'] = 0;
        }

        $result['records'] = $counts;


        foreach ($keys as $key) {

            $result['rows'][$i]['id'] = $key['AdPartner']['id'];
            $result['rows'][$i]['cell'] = array(
                '',
                $key['AdPartner']['id'],
                $key['AdPartner']['name'],
                date('d/m/Y', $key['AdPartner']['created_date']),
                date('d/m/Y h:i:s A', $key['AdPartner']['modified_date']),
                $key['AdPartner']['status'],
            );
            $i++;
        }

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    public function add() {
        if ($this->request->is('post')) {
            $this->AdPartner->create();

            $this->request->data['AdPartner']['status'] = 1;
            $this->request->data['AdPartner']['created_date'] = time();
            $this->request->data['AdPartner']['modified_date'] = time();
            
            if ($this->AdPartner->save($this->request->data)) {
                $this->Session->setFlash(__('AdPartner has been Add successfully'), 'swift_success');
                return $this->redirect(array('controller' => 'AdPartner', 'action' => 'index'));
            } else {
                $this->Session->setFlash(__("Unable to pasword AdPartner"), 'swift_failure');
                return $this->redirect(array('action' => 'index'));
            }
        }
    }

    public function edit($id = NULL) {
        $id = $this->request->params['pass'][0];
        $this->AdPartner->id = $id;

        if ($this->AdPartner->exists($this->AdPartner->id)) {
            if ($this->request->is('post') || $this->request->is('put')) {
                $this->request->data['AdPartner']['modified_date'] = time();

                if ($this->AdPartner->save($this->request->data)) {
                    $this->Session->setFlash(__('AdPartner has been Updated successfully'), 'swift_success');
                    return $this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(__("Unable to Add AdPartner"), 'swift_failure');
                    return $this->redirect(array('action' => 'add'));
                }
            } else {
                if (!$this->AdPartner->exists($id)) {
                    throw new NotFoundException(__('Invalid AdPartner'));
                }

                $options = array('conditions' => array('AdPartner.' . $this->AdPartner->primaryKey => $id));
                $this->request->data = $this->AdPartner->find('first', $options);


                $this->set('id', $this->request->data['AdPartner']['id']);
            }
        } else {
            $this->Session->setFlash(__("Not Exists Id in AdPartner"), 'swift_failure');
            return $this->redirect(array('action' => 'index'));
        }
    }

    public function inline() {

        $data = array();

        if (!empty($this->request->data) && $this->request->data['oper'] == 'edit') {
            $data['AdPartner'] = $this->request->data;
            $data['AdPartner']['modified_date'] = time();
            if ($this->AdPartner->save($data['AdPartner'])) {
                echo TRUE;
                exit;
            } else {
                echo FALSE;
                exit;
            }
        }

        if (!empty($this->request->data) && $this->request->data['oper'] == 'del') {
            $id_arr = explode(',', $this->request->data['id']);

            foreach ($id_arr as $del_id) {

                $this->AdPartner->delete($del_id);
            }
            exit;
        }
    }

    public function update_status() {
        $id = $this->request->data['id'];
        unset($this->request->data['id']);
        $this->request->data['AdPartner']['status'] = $this->request->data['status_val'];
        unset($this->request->data['status_val']);

        if (!$this->AdPartner->exists($id)) {
            throw new NotFoundException(__('Invalid AdPartner'));
        }

        if ($this->request->is('post') || $this->request->is('put')) {

            $this->request->data['AdPartner']['id'] = $id;
            if ($this->AdPartner->save($this->request->data)) {
                echo 1;
            } else {
                echo 2;
            }
        }
        exit;
    }

    public function IfExitstNames() {

        $name = trim($this->request->data['name']);
        unset($this->request->data['name']);

        if (isset($this->request->data['id']) && $name != NULL) {
            $id = $this->request->data['id'];
            $ifname = $this->AdPartner->find('count', array('conditions' => array('AdPartner.name' => $name, ' AdPartner.id !=' => $id)));
        } else {
            $ifname = $this->AdPartner->find('count', array('conditions' => array('AdPartner.name' => $name)));
        }

        $response = [];
        $response['code'] = 0;

        if (isset($ifname) && $ifname > 0) {
            $response['code'] = 201;
        } else {
            $response['code'] = 200;
        }

        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

}
