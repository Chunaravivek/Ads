<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

/**
 * CakePHP LoginLogsController
 * @author s4
 */
class LoginLogsController extends AppController {

    public $uses = array('LoginLogs', 'LoginLogs');  
    
    public function index() {
        $description = 'Manage LoginLogs';
        $keywords = 'Manage LoginLogs';
        $this->set(compact('keywords', 'description'));

    }
    
    public function records() {
        if (isset($this->request->query['sidx']) && $this->request->query['sidx'] != NULL)
            $order = "LoginLogs." . $this->request->query['sidx'] . " " . $this->request->query['sord'] . "";
        else {
            $order = "LoginLogs.created_date DESC";
        }

        $conditions = '1=1 ';

        if (isset($this->request->query['filters']) && $this->request->query['filters'] != '') {
            $filters = json_decode($this->request->query['filters']);
            $conditions = '';
            foreach ($filters->rules as $filter) {
                if ($filter->op == 'eq') {
                    $conditions .= "`LoginLogs." . $filter->field . "` = '$filter->data' AND ";
                } elseif ($filter->op == 'ne') {
                    $conditions .= "`LoginLogs." . $filter->field . "` !='$filter->data' AND ";
                } elseif ($filter->op == 'bw') {
                    $conditions .= "`LoginLogs." . $filter->field . "` Like '$filter->data%' AND ";
                } elseif ($filter->op == 'bn') {
                    $conditions .= "`LoginLogs." . $filter->field . "` NOT Like '$filter->data%' AND ";
                } elseif ($filter->op == 'ew') {
                    $conditions .= "`LoginLogs." . $filter->field . "` Like '%$filter->data' AND ";
                } elseif ($filter->op == 'en') {
                    $conditions .= "`LoginLogs." . $filter->field . "` NOT Like '%$filter->data' AND ";
                } elseif ($filter->op == 'cn') {
                    $conditions .= "`LoginLogs." . $filter->field . "` Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'nc') {
                    $conditions .= "`LoginLogs." . $filter->field . "` NOT Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'in') {
                    $conditions .= "`LoginLogs." . $filter->field . "` IN ($filter->data) AND ";
                } elseif ($filter->op == 'ni') {
                    $conditions .= "`LoginLogs." . $filter->field . "` NOT IN ($filter->data) AND ";
                }
            }
        }

        $i = 0;
        $result = array();

        if (isset($this->request->query['page']) && $this->request->query['page'] != '') {
            $result['page'] = (int) $this->request->query['page'];
        } else {
            $result['page'] = 1;
        }

        $conditions = substr($conditions, 0, -4);

        if (isset($this->request->query['rows']) && $this->request->query['rows'] != '') {
            $limit = (int) $this->request->query['rows'];
        } else {
            $limit = 10;
        }

        $offset = ($result['page'] - 1) * $limit;

        $keys = $this->LoginLogs->find('all', array('conditions' => array($conditions), 'order' => $order, 'limit' => $limit, 'offset' => $offset));

        $counts = $this->LoginLogs->find('count', array('conditions' => array($conditions), 'order' => $order));

        if ($counts > 0) {
            $result['total'] = ceil($counts / $limit);
        } else {
            $result['total'] = 0;
        }

        $result['records'] = $counts;


        foreach ($keys as $key) {
            $result['rows'][$i]['id'] = $key['LoginLogs']['id'];
            $result['rows'][$i]['cell'] = array(
                '',
                $key['LoginLogs']['id'],
                $key['LoginLogs']['username'],
                $key['LoginLogs']['password'],
                $key['LoginLogs']['ip_address'],
                $key['LoginLogs']['city'],
                $key['LoginLogs']['country'],
                $key['LoginLogs']['state'],
                date('d/m/Y h:i:s A', $key['LoginLogs']['created_date']),
                $key['LoginLogs']['status'],
            );
            $i++;
        }

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }
    
    public function update_status() {
        $id = $this->request->data['id'];
        unset($this->request->data['id']);
        $this->request->data['LoginLogs']['status'] = $this->request->data['status_val'];
        unset($this->request->data['status_val']);

        if (!$this->LoginLogs->exists($id)) {
            throw new NotFoundException(__('Invalid LoginLogs'));
        }

        if ($this->request->is('post') || $this->request->is('put')) {

            $this->request->data['LoginLogs']['id'] = $id;
            if ($this->LoginLogs->save($this->request->data)) {
                echo 1;
            } else {
                echo 2;
            }
        }
        exit;
    }
    
    public function inline() {
        
        $data = array();
        
        if(!empty($this->request->data) && $this->request->data['oper']=='edit'){
            $data['LoginLogs']=$this->request->data;
            $data['LoginLogs']['modified_date']= time();
            if ($this->LoginLogs->save($data['LoginLogs'])) {
                echo TRUE;exit;
            } else {
                echo FALSE;exit;
            }
        }
        
        if(!empty($this->request->data) && $this->request->data['oper']=='del'){
            $id_arr = explode(',',$this->request->data['id']);
            
            foreach($id_arr as $del_id) {
              
                $this->LoginLogs->delete($del_id);
            }
            exit;

        }
    }

}
