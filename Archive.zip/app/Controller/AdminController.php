
<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

class AdminController extends AppController {

    public $uses = array('Admin', 'LoginLogs');

    public function index() {
        $description = 'Manage Admin';
        $keywords = 'Manage Admin';
        $this->set(compact('keywords', 'description'));
    }

    public function records() {
        if (isset($this->request->query['sidx']) && $this->request->query['sidx'] != NULL)
            $order = "Admin." . $this->request->query['sidx'] . " " . $this->request->query['sord'] . "";
        else {
            $order = "Admin.modified_date DESC";
        }

        $conditions = '1=1 ';

        if (isset($this->request->query['filters']) && $this->request->query['filters'] != '') {
            $filters = json_decode($this->request->query['filters']);
            $conditions = '';
            foreach ($filters->rules as $filter) {
                if ($filter->op == 'eq') {
                    $conditions .= "`Admin." . $filter->field . "` = '$filter->data' AND ";
                } elseif ($filter->op == 'ne') {
                    $conditions .= "`Admin." . $filter->field . "` !='$filter->data' AND ";
                } elseif ($filter->op == 'bw') {
                    $conditions .= "`Admin." . $filter->field . "` Like '$filter->data%' AND ";
                } elseif ($filter->op == 'bn') {
                    $conditions .= "`Admin." . $filter->field . "` NOT Like '$filter->data%' AND ";
                } elseif ($filter->op == 'ew') {
                    $conditions .= "`Admin." . $filter->field . "` Like '%$filter->data' AND ";
                } elseif ($filter->op == 'en') {
                    $conditions .= "`Admin." . $filter->field . "` NOT Like '%$filter->data' AND ";
                } elseif ($filter->op == 'cn') {
                    $conditions .= "`Admin." . $filter->field . "` Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'nc') {
                    $conditions .= "`Admin." . $filter->field . "` NOT Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'in') {
                    $conditions .= "`Admin." . $filter->field . "` IN ($filter->data) AND ";
                } elseif ($filter->op == 'ni') {
                    $conditions .= "`Admin." . $filter->field . "` NOT IN ($filter->data) AND ";
                }
            }
        }

        $i = 0;
        $result = array();

        if (isset($this->request->query['page']) && $this->request->query['page'] != '') {
            $result['page'] = (int) $this->request->query['page'];
        } else {
            $result['page'] = 1;
        }

        $conditions = substr($conditions, 0, -4);

        if (isset($this->request->query['rows']) && $this->request->query['rows'] != '') {
            $limit = (int) $this->request->query['rows'];
        } else {
            $limit = 10;
        }

        $offset = ($result['page'] - 1) * $limit;

        $keys = $this->Admin->find('all', array('conditions' => array($conditions), 'order' => $order, 'limit' => $limit, 'offset' => $offset));

        $counts = $this->Admin->find('count', array('conditions' => array($conditions), 'order' => $order));

        if ($counts > 0) {
            $result['total'] = ceil($counts / $limit);
        } else {
            $result['total'] = 0;
        }

        $result['records'] = $counts;


        foreach ($keys as $key) {

            $result['rows'][$i]['id'] = $key['Admin']['id'];
            $result['rows'][$i]['cell'] = array(
                '',
                $key['Admin']['id'],
                $key['Admin']['full_name'],
                $key['Admin']['email'],
                $key['Admin']['password'],
                date('d/m/Y', $key['Admin']['created_date']),
                date('d/m/Y h:i:s A', $key['Admin']['modified_date']),
                $key['Admin']['status'],
            );
            $i++;
        }

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    public function login() {
        $this->layout = 'user';

        if ($this->request->is('post')) {

            $email = $this->request->data['Admin']['email'];
            $pass = $this->request->data['Admin']['password'];

            $check = $this->Admin->find('first', array(
                'conditions' => array(
                    'AND' => array(
                        array('Admin.email' => $email),
                        array('Admin.password' => $pass)
                    )
                )
            ));

            if ($check != null) {

                $get_ip = $this->request->ClientIp();

                $ip_api = '';
                if ($this->request->ClientIp() == '::1') {
                    $ip_api = "https://pro.ip-api.com/json/?key=YqXjKcCviGqmr5z";
                } else {

                    $ip_api = "https://pro.ip-api.com/json/$get_ip?key=YqXjKcCviGqmr5z";
                }

                $ip_response = file_get_contents($ip_api);

                $ip_details = json_decode($ip_response, true);

                if (isset($ip_details) && $ip_details['status'] == 'success') {
                    $city = $ip_details['city'];
                    $country = $ip_details['country'];
                    $state = $ip_details['regionName'];
                    $ip_address = $ip_details['query'];
                    $created_date = time();

                    $this->LoginLogs->create();

                    $logs_arr = array();
                    $logs_arr['LoginLogs'] = array(
                        'admin_id' => $check['Admin']['id'],
                        'username' => $check['Admin']['full_name'],
                        'password' => $check['Admin']['password'],
                        'city' => $city,
                        'country' => $country,
                        'state' => $state,
                        'ip_address' => $ip_address,
                        'created_date' => $created_date,
                        'status' => 1,
                    );

                    if ($this->LoginLogs->save($logs_arr)) {

                        $this->Session->write('admin_id', $check['Admin']['id']);
                        $this->Session->write('email', $check['Admin']['email']);
                        $this->Session->write('status', $check['Admin']['status']);
                        $this->Session->write('full_name', $check['Admin']['full_name']);

                        if (isset($this->request->query['returnURL'])) {
                            $controller = $this->request->query['returnURL'];
                            $this->redirect(array('controller' => $controller));
                        } else {

                            $this->redirect(array('controller' => 'Dashboard', 'action' => 'index'));
                        }
                    } else {
                        $this->Session->setFlash(__('The LoginLogs could not be saved. Please, try again.'), 'swift_failure');
                    }
                }
            } else {

                $this->Session->setFlash(__('Invalid email or Password'), 'swift_failure');
            }
        }
    }

    public function logout() {

        $this->Session->delete('status');
        $this->Session->delete('admin_id');
        $this->Session->delete('email');
        $this->Session->delete('full_name');

        $this->redirect(array('controller' => 'Admin', 'action' => 'login'));
    }

    public function add() {
        if ($this->request->is('post')) {
            $this->Admin->create();

            $this->request->data['Admin']['status'] = 1;
            $this->request->data['Admin']['created_date'] = time();
            $this->request->data['Admin']['modified_date'] = time();

            if ($this->Admin->save($this->request->data)) {
                $this->Session->setFlash(__('Admin has been Add successfully'), 'swift_success');
                return $this->redirect(array('controller' => 'Admin', 'action' => 'index'));
            } else {
                $this->Session->setFlash(__("Unable to pasword Admin"), 'swift_failure');
                return $this->redirect(array('action' => 'index'));
            }
        }
    }

    public function edit($id = NULL) {
        $id = $this->request->params['pass'][0];
        $this->Admin->id = $id;

        if ($this->Admin->exists($this->Admin->id)) {
            if ($this->request->is('post') || $this->request->is('put')) {
                $this->request->data['Admin']['modified_date'] = time();

                if ($this->Admin->save($this->request->data)) {
                    $this->Session->setFlash(__('Admin has been Updated successfully'), 'swift_success');
                    return $this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(__("Unable to Add Admin"), 'swift_failure');
                    return $this->redirect(array('action' => 'add'));
                }
            } else {
                if (!$this->Admin->exists($id)) {
                    throw new NotFoundException(__('Invalid Admin'));
                }

                $options = array('conditions' => array('Admin.' . $this->Admin->primaryKey => $id));
                $this->request->data = $this->Admin->find('first', $options);


                $this->set('id', $this->request->data['Admin']['id']);
            }
        } else {
            $this->Session->setFlash(__("Not Exists Id in Admin"), 'swift_failure');
            return $this->redirect(array('action' => 'index'));
        }
    }

    public function inline() {

        $data = array();

        if (!empty($this->request->data) && $this->request->data['oper'] == 'edit') {
            $data['Admin'] = $this->request->data;
            $data['Admin']['modified_date'] = time();
            if ($this->Admin->save($data['Admin'])) {
                echo TRUE;
                exit;
            } else {
                echo FALSE;
                exit;
            }
        }

        if (!empty($this->request->data) && $this->request->data['oper'] == 'del') {
            $id_arr = explode(',', $this->request->data['id']);

            foreach ($id_arr as $del_id) {

                $this->Admin->delete($del_id);
            }
            exit;
        }
    }

    public function update_status() {
        $id = $this->request->data['id'];
        unset($this->request->data['id']);
        $this->request->data['Admin']['status'] = $this->request->data['status_val'];
        unset($this->request->data['status_val']);

        if (!$this->Admin->exists($id)) {
            throw new NotFoundException(__('Invalid Admin'));
        }

        if ($this->request->is('post') || $this->request->is('put')) {

            $this->request->data['Admin']['id'] = $id;
            if ($this->Admin->save($this->request->data)) {
                echo 1;
            } else {
                echo 2;
            }
        }
        exit;
    }

}
