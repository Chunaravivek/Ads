<?php

ini_set('memory_limit', '256M');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

App::import('Vendor', 'googleplayscraper', array('file' => 'googleplayscraper/autoload.php'));

use Raulr\GooglePlayScraper\Scraper;

class ApplicationsController extends AppController {

    public $uses = array('Applications', 'Accounts');
    
    public $components = array('AppCode');

    public function index() {
 
        $description = 'Manage Applications';
        $keywords = 'Manage Applications';
        $this->set(compact('keywords', 'description'));

        $accounts = $this->Accounts->find('all');
        $this->set("accounts", $accounts);
    }

    public function records() {

        if (isset($this->request->query['sidx']) && $this->request->query['sidx'] != NULL)
            $order = "Applications." . $this->request->query['sidx'] . " " . $this->request->query['sord'] . "";
        else {
            $order = "Applications.modified_date DESC";
        }

        $conditions = '1=1 AND ';
        
        if (isset($this->params->query['account_id']) && $this->params->query['account_id'] != NULL) {
            
            $ac = $this->params->query['account_id'];            
            $conditions.=" Applications.account_id = $ac AND ";
        }
       
        if (isset($this->params->query['play_store']) && $this->params->query['play_store'] != NULL) {
            
            $part = $this->params->query['play_store'];
            $conditions.=" Applications.play_store = $part AND ";
           
        }
        
        if (isset($this->params->query['package_id']) && $this->params->query['package_id'] != NULL) {
            $part = $this->params->query['package_id'];
            if ($part == 1) {
                $conditions.=" Applications.package_name = '' AND ";
            } else {
                $conditions.=" Applications.package_name != '' AND ";
            }
        }

        if (isset($this->request->query['filters']) && $this->request->query['filters'] != '') {
            $filters = json_decode($this->request->query['filters']);
            $conditions = '';
            foreach ($filters->rules as $filter) {
                if ($filter->op == 'eq') {
                    $conditions .= "`Applications." . $filter->field . "` = '$filter->data' AND ";
                } elseif ($filter->op == 'ne') {
                    $conditions .= "`Applications." . $filter->field . "` !='$filter->data' AND ";
                } elseif ($filter->op == 'bw') {
                    $conditions .= "`Applications." . $filter->field . "` Like '$filter->data%' AND ";
                } elseif ($filter->op == 'bn') {
                    $conditions .= "`Applications." . $filter->field . "` NOT Like '$filter->data%' AND ";
                } elseif ($filter->op == 'ew') {
                    $conditions .= "`Applications." . $filter->field . "` Like '%$filter->data' AND ";
                } elseif ($filter->op == 'en') {
                    $conditions .= "`Applications." . $filter->field . "` NOT Like '%$filter->data' AND ";
                } elseif ($filter->op == 'cn') {
                    $conditions .= "`Applications." . $filter->field . "` Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'nc') {
                    $conditions .= "`Applications." . $filter->field . "` NOT Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'in') {
                    $conditions .= "`Applications." . $filter->field . "` IN ($filter->data) AND ";
                } elseif ($filter->op == 'ni') {
                    $conditions .= "`Applications." . $filter->field . "` NOT IN ($filter->data) AND ";
                }
            }
        }

        $i = 0;
        $result = array();

        if (isset($this->request->query['page']) && $this->request->query['page'] != '') {
            $result['page'] = (int) $this->request->query['page'];
        } else {
            $result['page'] = 1;
        }

        $conditions = substr($conditions, 0, -4);

        if (isset($this->request->query['rows']) && $this->request->query['rows'] != '') {
            $limit = (int) $this->request->query['rows'];
        } else {
            $limit = 10;
        }

        $offset = ($result['page'] - 1) * $limit;

        $keys = $this->Applications->find('all', array('conditions' => array($conditions), 'order' => $order, 'limit' => $limit, 'offset' => $offset));

        $counts = $this->Applications->find('count', array('conditions' => array($conditions), 'order' => $order));

        if ($counts > 0) {
            $result['total'] = ceil($counts / $limit);
        } else {
            $result['total'] = 0;
        }

        $result['records'] = $counts;


        foreach ($keys as $key) {

            $result['rows'][$i]['id'] = $key['Applications']['id'];
            $result['rows'][$i]['cell'] = array(
                '',
                $key['Applications']['id'],
                $key['Applications']['name'],
                $key['Applications']['app_version'],
                $key['Applications']['package_name'],
                $key['Applications']['app_code'],
                $key['Accounts']['name'],
                $key['Applications']['account_url'],
                $key['Applications']['firebase_id'],
                date('d/m/Y', $key['Applications']['created_date']),
                date('d/m/Y h:i:s A', $key['Applications']['modified_date']),
                $key['Applications']['recmnd_status'],
                $key['Applications']['status'],
                $key['Applications']['play_store'],
            );
            $i++;
        }

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    public function add() {
        $new_data_arr = [];
        if ($this->request->is('post')) {
            $this->Applications->create();

            $post_arr = array_map('trim', $this->request->data['Applications']);

            $new_data_arr['Applications'] = $post_arr;
            
            $app_code = $this->AppCode->randomPrefix(6);
            
            $checkcode = $this->Applications->find('first', array('conditions' => array('Applications.app_code' => $app_code)));

            if (empty($checkcode)) {
                
                $get_account_name = $this->Accounts->find('list', array('conditions' => array('Accounts.id' => $new_data_arr['Applications']['account_id'])));
               
                $string_replace_account = str_replace(' ', '+', implode(',', $get_account_name));
                
                $new_data_arr['Applications']['app_code'] = $app_code;
                $new_data_arr['Applications']['account_url'] = 'https://play.google.com/store/apps/developer?id='.$string_replace_account;
                $new_data_arr['Applications']['sender_id'] = isset($new_data_arr['Applications']['sender_id']) ? $new_data_arr['Applications']['sender_id'] : 'undefined';
                $new_data_arr['Applications']['play_store'] = 1;
                $new_data_arr['Applications']['status'] = 1;
                $new_data_arr['Applications']['created_date'] = time();
                $new_data_arr['Applications']['modified_date'] = time();

                if ($this->Applications->save($new_data_arr)) {
                    $this->Session->setFlash(__('Applications has been Add successfully'), 'swift_success');
                    return $this->redirect(array('controller' => 'Applications', 'action' => 'index'));
                } else {
                    $this->Session->setFlash(__("Unable to pasword Applications"), 'swift_failure');
                    return $this->redirect(array('action' => 'index'));
                }
            } else {
                $this->Session->setFlash(__($new_data_arr['Applications']['app_code'] . " Already exists app_code"), 'swift_failure');
                return $this->redirect(array('action' => 'index'));
            }
        }

        $account = $this->Accounts->find('list');
        $this->set('accounts', $account);
    }

    public function edit($id = NULL) {
        $id = $this->request->params['pass'][0];
        $this->Applications->id = $id;

        if ($this->Applications->exists($this->Applications->id)) {
            $edit_arr = [];
            if ($this->request->is('post') || $this->request->is('put')) {

                $post_arr = array_map('trim', $this->request->data['Applications']);

                $edit_arr['Applications'] = $post_arr;
                $edit_arr['Applications']['modified_date'] = time();

                if ($this->Applications->save($edit_arr)) {
                    $this->Session->setFlash(__('Applications has been Updated successfully'), 'swift_success');
                    return $this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(__("Unable to Add Applications"), 'swift_failure');
                    return $this->redirect(array('action' => 'add'));
                }
            } else {
                if (!$this->Applications->exists($id)) {
                    throw new NotFoundException(__('Invalid Applications'));
                }

                $options = array('conditions' => array('Applications.' . $this->Applications->primaryKey => $id));
                $this->request->data = $this->Applications->find('first', $options);

                $account = $this->Accounts->find('list');
                $this->set('accounts', $account);
                
                $this->set('id', $this->request->data['Applications']['id']);
            }
        } else {
            $this->Session->setFlash(__("Not Exists Id in Applications"), 'swift_failure');
            return $this->redirect(array('action' => 'index'));
        }
    }

    public function inline() {

        $data = array();

        if (!empty($this->request->data) && $this->request->data['oper'] == 'edit') {
            $data['Applications'] = $this->request->data;
            $data['Applications']['modified_date'] = time();
            if ($this->Applications->save($data['Applications'])) {
                echo TRUE;
                exit;
            } else {
                echo FALSE;
                exit;
            }
        }

        if (!empty($this->request->data) && $this->request->data['oper'] == 'del') {
            $id_arr = explode(',', $this->request->data['id']);

            foreach ($id_arr as $del_id) {

                $this->Applications->delete($del_id);
            }
            exit;
        }
    }

    public function update_status() {
        $id = $this->request->data['id'];
        unset($this->request->data['id']);
        $this->request->data['Applications']['status'] = $this->request->data['status_val'];
        unset($this->request->data['status_val']);

        if (!$this->Applications->exists($id)) {
            throw new NotFoundException(__('Invalid Applications'));
        }

        if ($this->request->is('post') || $this->request->is('put')) {

            $this->request->data['Applications']['id'] = $id;
            if ($this->Applications->save($this->request->data)) {
                echo 1;
            } else {
                echo 2;
            }
        }
        exit;
    }

    public function getlinks() {
        $response = [];
        $response['code'] = 0;
        $response['ifname'] = 0;
        $scraper = new Scraper();
        
        if (isset($this->request->data['id']) && $this->request->data['id'] != NULL && isset($this->request->data['package_name']) && $this->request->data['package_name'] != NULL) {
            $id = $this->request->data['id'];
            $package_name = trim($this->request->data['package_name']);
            $response['ifname'] = $this->Applications->find('count', array('conditions' => array('Applications.package_name' => $package_name, ' Applications.id !=' => $id)));
        } else {
            if (isset($this->request->data['package_name']) && $this->request->data['package_name'] != NULL) {
                $package_name = trim($this->request->data['package_name']);
                $response['ifname'] = $this->Applications->find('count', array('conditions' => array('Applications.package_name' => $package_name)));
                
            }
        }
        
        if (isset($response['ifname']) && $response['ifname'] > 0) {
            
            $response['code'] = 201;
        } else {
            
            $file = 'http://play.google.com/store/apps/details?id='.$package_name;
            $file_headers = @get_headers($file);
           
            if(!$file_headers || $file_headers[14] == 'HTTP/1.0 404 Not Found') {
                $response['code'] = 200;
            }
            else {
                $response['code'] = 202;
            }
        }
        unset($response['ifname']);
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    function recmnd_status() {
        $id = $this->request->data['id'];
        unset($this->request->data['id']);
        $this->request->data['Applications']['recmnd_status'] = $this->request->data['recmnd_status'];
        unset($this->request->data['recmnd_status']);
        $time = time();
        if (!$this->Applications->exists($id)) {
            throw new NotFoundException(__('Invalid Appdetail'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->request->data['Applications']['id'] = $id;
            $this->request->data['Applications']['modified_date'] = $time;
            if ($this->Applications->save($this->request->data)) {
                echo 1;
            } else {
                echo 2;
            }
        }
        exit;
    }

}
