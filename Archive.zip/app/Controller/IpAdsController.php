<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

/**
 * CakePHP IpAdsController
 * @author s4ittech
 */
class IpAdsController extends AppController {

    public $uses = array('IpAds', 'Applications', 'Accounts', 'AdPartner', 'AdsPartnerWises', 'Cities');

    function index() {

        $description = 'Manage AdsPartnerWises';
        $keywords = 'Manage AdsPartnerWises';
        $this->set(compact('keywords', 'description'));

        $accounts = $this->Accounts->find('all');
        $this->set("accounts", $accounts);

        $cities = $this->Cities->find('all');
        $this->set("cities", $cities);
    }

    public function records() {

        if (isset($this->request->query['sidx']) && $this->request->query['sidx'] != NULL)
            $order = "IpAds." . $this->request->query['sidx'] . " " . $this->request->query['sord'] . "";
        else {
            $order = "IpAds.modified_date DESC";
        }

        $conditions = '1=1 AND ';

        if (isset($this->params->query['account_id']) && $this->params->query['account_id'] != NULL) {

            $ac = $this->params->query['account_id'];
            $conditions .= "IpAds.acc_id = $ac AND ";
        }

        if (isset($this->params->query['city_id']) && $this->params->query['city_id'] != NULL) {
            $ip = $this->params->query['city_id'];

            $conditions .= " IpAds.city_id = $ip AND ";
        }

        if (isset($this->request->query['filters']) && $this->request->query['filters'] != '') {
            $filters = json_decode($this->request->query['filters']);
            $conditions = '';
            foreach ($filters->rules as $filter) {
                if ($filter->op == 'eq') {
                    $conditions .= "`IpAds." . $filter->field . "` = '$filter->data' AND ";
                } elseif ($filter->op == 'ne') {
                    $conditions .= "`IpAds." . $filter->field . "` !='$filter->data' AND ";
                } elseif ($filter->op == 'bw') {
                    $conditions .= "`IpAds." . $filter->field . "` Like '$filter->data%' AND ";
                } elseif ($filter->op == 'bn') {
                    $conditions .= "`IpAds." . $filter->field . "` NOT Like '$filter->data%' AND ";
                } elseif ($filter->op == 'ew') {
                    $conditions .= "`IpAds." . $filter->field . "` Like '%$filter->data' AND ";
                } elseif ($filter->op == 'en') {
                    $conditions .= "`IpAds." . $filter->field . "` NOT Like '%$filter->data' AND ";
                } elseif ($filter->op == 'cn') {
                    $conditions .= "`IpAds." . $filter->field . "` Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'nc') {
                    $conditions .= "`IpAds." . $filter->field . "` NOT Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'in') {
                    $conditions .= "`IpAds." . $filter->field . "` IN ($filter->data) AND ";
                } elseif ($filter->op == 'ni') {
                    $conditions .= "`IpAds." . $filter->field . "` NOT IN ($filter->data) AND ";
                }
            }
        }

        $i = 0;
        $result = array();

        if (isset($this->request->query['page']) && $this->request->query['page'] != '') {
            $result['page'] = (int) $this->request->query['page'];
        } else {
            $result['page'] = 1;
        }

        $conditions = substr($conditions, 0, -4);

        if (isset($this->request->query['rows']) && $this->request->query['rows'] != '') {
            $limit = (int) $this->request->query['rows'];
        } else {
            $limit = 10;
        }

        $offset = ($result['page'] - 1) * $limit;

        $keys = $this->IpAds->find('all', array('conditions' => array($conditions), 'order' => $order, 'limit' => $limit, 'offset' => $offset));

        $counts = $this->IpAds->find('count', array('conditions' => array($conditions), 'order' => $order));

        if ($counts > 0) {
            $result['total'] = ceil($counts / $limit);
        } else {
            $result['total'] = 0;
        }

        $result['records'] = $counts;

        foreach ($keys as $key) {

            $app = $this->Applications->find('first', array('conditions' => array('Applications.app_code' => $key['IpAds']['app_code'])));
            $cities = $this->Cities->find('first', array('conditions' => array('Cities.id' => $key['IpAds']['city_id'])));

            $app_name = isset($app['Applications']['name']) ? $app['Applications']['name'] : '';
            $ac_name = isset($app['Accounts']['name']) ? $app['Accounts']['name'] : '';
            $cities_name = isset($cities['Cities']['name']) ? $cities['Cities']['name'] : '';

            $result['rows'][$i]['id'] = $key['IpAds']['id'];
            $result['rows'][$i]['cell'] = array(
                '',
                $key['IpAds']['id'],
                $ac_name,
                $key['IpAds']['app_name'],
                $key['IpAds']['app_code'],
                $cities_name,
                $key['IpAds']['json_path'],
                isset($app['Applications']['package_name']) ? $app['Applications']['package_name'] : '',
                isset($app['Applications']['play_store']) ? $app['Applications']['play_store'] : '',
                date('d/m/Y', $key['IpAds']['created_date']),
                date('d/m/Y h:i:s A', $key['IpAds']['modified_date']),
                $key['IpAds']['status'],
            );

            $i++;
        }

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    function inline() {
        $data = array();
        if (!empty($this->params->data) && $this->params->data['oper'] == 'edit') {
            $data['IpAds'] = $this->params->data;
            $data['IpAds']['modified_date'] = time();
            if ($this->IpAds->save($data['IpAds'])) {
                echo TRUE;
                exit;
            } else {
                echo FALSE;
                exit;
            }
        }
        if (!empty($this->params->data) && $this->params->data['oper'] == 'del') {
            $id_arr = explode(',', $this->params->data['id']);

            foreach ($id_arr as $del_id) {

                $this->IpAds->delete($del_id);
            }exit;
        }
    }

    public function edit($id = null) {

        if (!$this->IpAds->exists($id)) {
            throw new NotFoundException(__('Invalid Ad id'));
        }

        if ($this->request->is('post') || $this->request->is('put')) {

            $city_ids = $this->request->data['IpAds']['city_id'];
            unset($this->request->data['IpAds']['city_id']);

            $old_city_id = $this->request->data['IpAds']['old_city_id'];

            $app = $this->Applications->find('first', array('conditions' => array('Applications.app_code' => $this->request->data['IpAds']['app_code'])));
            $app_name = $app['Applications']['name'];
            $add = 0;
            $update = 0;
            foreach ($city_ids as $city_id) {

                $city_arr['IpAds'] = array_map('trim', $this->request->data['IpAds']);

                $city_arr['IpAds']['app_name'] = $app_name;
                unset($city_arr['IpAds']['modified_date']);
                unset($city_arr['IpAds']['created_date']);
                unset($city_arr['IpAds']['id']);

                $ifexits = $this->IpAds->find('first', array('conditions' => array('IpAds.app_code' => $this->request->data['IpAds']['app_code'], 'IpAds.city_id' => $city_id)));

                if (count($ifexits) > 0) {
//                    Already Exist Fields Updated

                    $city_arr['IpAds']['id'] = $ifexits['IpAds']['id'];
                    $city_arr['IpAds']['modified_date'] = time();

                    if ($this->IpAds->save($city_arr)) {
                        $update++;
                    } else {
                        $this->Session->setFlash(__('The IpAds could not be saved. Please, try again.'), 'swift_failure');
                    }
                } else {
//                    Not Exists Fields New Entry Inserts

                    $this->IpAds->create();
                    $city_arr['IpAds']['created_date'] = time();
                    $city_arr['IpAds']['modified_date'] = time();
                    $city_arr['IpAds']['city_id'] = $city_id;

                    if ($this->IpAds->save($city_arr)) {
                        $add++;
                    } else {
                        $this->Session->setFlash(__('The IpAds could not be saved. Please, try again.'), 'swift_failure');
                    }
                }
            }
            $this->Session->setFlash(__('Added ' . ($add) . ' And ' . ($update) . ' Updated IpAds'), 'swift_success');
            return $this->redirect(array('action' => 'index'));
        } else {
            $options = array('conditions' => array('IpAds.' . $this->IpAds->primaryKey => $id));
            $this->request->data = $this->IpAds->find('first', $options);

            $this->set('id', $this->request->data['IpAds']['id']);

            $city_id = $this->request->data['IpAds']['city_id'];
            $this->set('city_id', $city_id);

            $anim = $this->request->data['IpAds']['anim'];
            $this->set('anim', $anim);

            $ad_call = $this->request->data['IpAds']['ad_call'];
            $this->set('ad_call', $ad_call);

            $adptive_banner = $this->request->data['IpAds']['adptive_banner'];
            $this->set('adptive_banner', $adptive_banner);

            $back_ad_set = $this->request->data['IpAds']['back_ad_set'];
            $this->set('back_ad_set', $back_ad_set);

            $exit_native_ad = $this->request->data['IpAds']['exit_native_ad'];
            $this->set('exit_native_ad', $exit_native_ad);

            $qureka_ad = $this->request->data['IpAds']['qureka_ad'];
            $this->set('qureka_ad', $qureka_ad);

            $app_status = $this->request->data['IpAds']['app_status'];
            $this->set('app_status', $app_status);

            $in_house = $this->request->data['IpAds']['in_house'];
            $this->set('in_house', $in_house);

            $ad_dialogue = $this->request->data['IpAds']['ad_dialogue'];
            $this->set('ad_dialogue', $ad_dialogue);

            $open_inter = $this->request->data['IpAds']['open_inter'];
            $this->set('open_inter', $open_inter);

            $open_inter = $this->request->data['IpAds']['open_inter'];
            $this->set('open_inter', $open_inter);

            $rec_apps = $this->request->data['IpAds']['rec_apps'];
            $this->set('rec_apps', $rec_apps);

            $native_pre_load = $this->request->data['IpAds']['native_pre_load'];
            $this->set('native_pre_load', $native_pre_load);

            $multiple_start = $this->request->data['IpAds']['multiple_start'];
            $this->set('multiple_start', $multiple_start);

            $nav_bar = $this->request->data['IpAds']['nav_bar'];
            $this->set('nav_bar', $nav_bar);

            $banner_native = $this->request->data['IpAds']['banner_native'];
            $this->set('banner_native', $banner_native);

            $vpn_detect = $this->request->data['IpAds']['vpn_detect'];
            $this->set('vpn_detect', $vpn_detect);

            $vpn_button = $this->request->data['IpAds']['vpn_button'];
            $this->set('vpn_button', $vpn_button);

            $transparent = $this->request->data['IpAds']['transparent'];
            $this->set('transparent', $transparent);

            $ad_partner = $this->AdPartner->find('list');
            $this->set('ad_partners', $ad_partner);

            $account = $this->Accounts->find('list');
            $this->set('accounts', $account);

            $app_arr = $this->Applications->find('all');

            $app_list = array();
            foreach ($app_arr as $app) {
                $app_code = $app['Applications']['app_code'];
                $app_name = $app['Applications']['name'];
                $app_list[$app_code] = $app_name;
            }
//         
            $this->set("applications", $app_list);

            $ip_arr = $this->Cities->find('all');

            $ip_list = array();
            foreach ($ip_arr as $app) {
                $cities_id = $app['Cities']['id'];
                $cities_name = $app['Cities']['name'];
                $ip_list[$cities_id] = $cities_name;
            }

            $this->set("ip", $ip_list);

            $ads_id_app_code = $this->request->data['IpAds']['app_code'];
            $ads_id_acc_id = $this->request->data['IpAds']['acc_id'];

            $conditions_query = "AdsPartnerWises.app_code = '$ads_id_app_code' AND AdsPartnerWises.acc_id = $ads_id_acc_id ";
            $adsparnterwises = $this->AdsPartnerWises->find('all', array('conditions' => array($conditions_query)));

            /* google_app_id S */
            $google_app_id_select2 = array();
            foreach ($adsparnterwises as $google_app_id) {
                $AdsPartnerWises_id = $google_app_id['AdsPartnerWises']['google_app_id'];

                $partner_name = $google_app_id['AdPartner']['name'];
                $google_app_id_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_app_id', $google_app_id_select2);
            $this->set('google_app_id_val', $this->request->data['IpAds']['google_app_id']);
            /* google_app_id E */

            /* google_appopen S */
            $google_appopen_select = array();
            foreach ($adsparnterwises as $google_appopen) {

                $AdsPartnerWises_id = $google_appopen['AdsPartnerWises']['google_appopen'];

                $partner_name = $google_appopen['AdPartner']['name'];
                $google_appopen_select[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_appopen', $google_appopen_select);
            $this->set('google_appopen_val', $this->request->data['IpAds']['google_appopen']);
            /* google_appopen E */

            /* google_appopen 2 S */
            $this->set('google_appopen_2_val', $this->request->data['IpAds']['google_appopen_2']);
            /* google_appopen 2 E */

            /* google_appopen 3 S */
            $this->set('google_appopen_3_val', $this->request->data['IpAds']['google_appopen_3']);
            /* google_appopen 3 E */

            /* google_fullad S */
            $google_fullad_select2 = array();
            foreach ($adsparnterwises as $google_fullad) {
                $AdsPartnerWises_id = $google_fullad['AdsPartnerWises']['google_fullad'];

                $partner_name = $google_fullad['AdPartner']['name'];
                $google_fullad_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_fullad', $google_fullad_select2);
            $this->set('google_fullad_val', $this->request->data['IpAds']['google_fullad']);
            /* google_fullad E */

            /* google_fullad 2 S */
            $this->set('google_fullad_2_val', $this->request->data['IpAds']['google_fullad_2']);
            /* google_fullad 2 E */

            /* google_fullad 3 S */
            $this->set('google_fullad_3_val', $this->request->data['IpAds']['google_fullad_3']);
            /* google_fullad 3 E */



            /* google_fullad_splash S */
            $google_fullad_splash_select2 = array();
            foreach ($adsparnterwises as $google_fullad_splash) {
                $AdsPartnerWises_id = $google_fullad_splash['AdsPartnerWises']['google_fullad_splash'];

                $partner_name = $google_fullad_splash['AdPartner']['name'];
                $google_fullad_splash_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_fullad_splash', $google_fullad_splash_select2);
            $this->set('google_fullad_splash_val', $this->request->data['IpAds']['google_fullad_splash']);
            /* google_fullad_splash E */

            /* google_reward_ad S */
            $google_reward_ad_select2 = array();
            foreach ($adsparnterwises as $google_reward_ad) {
                $AdsPartnerWises_id = $google_reward_ad['AdsPartnerWises']['google_reward_ad'];

                $partner_name = $google_reward_ad['AdPartner']['name'];
                $google_reward_ad_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_reward_ad', $google_reward_ad_select2);
            $this->set('google_reward_ad_val', $this->request->data['IpAds']['google_reward_ad']);
            /* google_reward_ad E */

            /* google_banner S */
            $google_banner_select2 = array();
            foreach ($adsparnterwises as $google_banner) {
                $AdsPartnerWises_id = $google_banner['AdsPartnerWises']['google_banner'];

                $partner_name = $google_banner['AdPartner']['name'];
                $google_banner_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_banner', $google_banner_select2);
            $this->set('google_banner_val', $this->request->data['IpAds']['google_banner']);
            /* google_banner E */

            /* google_native S */
            $google_native_select2 = array();
            foreach ($adsparnterwises as $google_native) {
                $AdsPartnerWises_id = $google_native['AdsPartnerWises']['google_native'];

                $partner_name = $google_native['AdPartner']['name'];
                $google_native_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_native', $google_native_select2);
            $this->set('google_native_val', $this->request->data['IpAds']['google_native']);
            /* google_native E */

            /* google_native 2 S */
            $this->set('google_native_2_val', $this->request->data['IpAds']['google_native_2']);
            /* google_native 2 E */

            /* google_native 3 S */
            $this->set('google_native_3_val', $this->request->data['IpAds']['google_native_3']);
            /* google_native 3 E */

            /* google_native_banner S */
            $google_native_banner_select2 = array();
            foreach ($adsparnterwises as $google_native_banner) {
                $AdsPartnerWises_id = $google_native_banner['AdsPartnerWises']['google_native_banner'];

                $partner_name = $google_native_banner['AdPartner']['name'];
                $google_native_banner_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_native_banner', $google_native_banner_select2);
            $this->set('google_native_banner_val', $this->request->data['IpAds']['google_native_banner']);
            /* google_native_banner E */
        }
    }

    public function add() {
        if ($this->request->is('post')) {
            
            $city_ids = $this->request->data['IpAds']['city_id'];
            unset($this->request->data['IpAds']['city_id']);
            
            $count = 0;
            $add_data_arr = [];
            
            foreach ($city_ids as $city_id) {
                if (isset($city_id) && $city_id != NULL) {

                    $post_arr = array_map('trim', $this->request->data['IpAds']);

                    $add_data_arr['IpAds'] = $post_arr;

                    $checkcode = $this->IpAds->find('first', array('conditions' => array('AND' => array('IpAds.app_code' => $add_data_arr['IpAds']['app_code'], 'IpAds.city_id' => $city_id))));
                    if (empty($checkcode)) {

                        $add_data_arr['IpAds']['city_id'] = $city_id;
                        $add_data_arr['IpAds']['status'] = 1;
                        $add_data_arr['IpAds']['created_date'] = time();
                        $add_data_arr['IpAds']['modified_date'] = time();
                        
                        $app = $this->Applications->find('first', array('conditions' => array('Applications.app_code' => $add_data_arr['IpAds']['app_code'])));
                        
                        $add_data_arr['IpAds']['app_name'] = $app['Applications']['name'];
                        
                        if ($this->IpAds->save($add_data_arr)) {
                            $count++;
                        } else {
                            $this->Session->setFlash(__('The IpAds could not be saved. Please, try again.'), 'swift_failure');
                        }
                    } else {
                        $this->Session->setFlash(__($add_data_arr['IpAds']['app_code'] . " Already exists app_code"), 'swift_failure');
                        return $this->redirect(array('action' => 'index'));
                    }
                }
            }

            $this->Session->setFlash(__('Added ' . ($count) . ' IpAds'), 'swift_success');
            return $this->redirect(array('action' => 'index'));
        }

        $account = $this->Accounts->find('list');
        $this->set('accounts', $account);

        $applications = $this->Applications->find('list');
        $this->set('applications', $applications);

        $ip_arr = $this->Cities->find('all');

        $ip_list = array();
        foreach ($ip_arr as $app) {
            $cities_id = $app['Cities']['id'];
            $cities_name = $app['Cities']['name'];
            $ip_list[$cities_id] = $cities_name;
        }

        $this->set("ip", $ip_list);

        $app_path_link = $this->IpAds->find('first');
        if (count($app_path_link) > 0) {
            $this->set("app_path_link", isset($app_path_link['IpAds']['path']) ? $app_path_link['IpAds']['path'] : "");
        } else {
            $this->set("app_path_link", 'https://play.google.com/store/apps/details?id=com.rc.ffskintool.freediamondemote');
        }

        $adsparnterwises = $this->AdsPartnerWises->find('all');
        $this->set('adsparnterwises', $adsparnterwises);
    }

    function get_area() {
        $type_id = $_REQUEST['type_id'];

        $data = "";
        $cities = $this->Cities->find('all', array('conditions' => array('Cities.type_id' => $type_id))); //,array('conditions' => array('Category.id' => $category_id))); 
        $data .= '<option value=""> -- Select AREA -- </option>';
        foreach ($cities as $citie) {
            $data .= '<option value="' . $citie['Cities']['id'] . '">' . $citie['Cities']['name'] . '</option>';
        }
        echo $data;
        exit;
    }

    function get_application() {
        $ac_id = $_REQUEST['ac_id'];

        $data = "";
        $applications = $this->Applications->find('all', array('conditions' => array('Applications.account_id' => $ac_id))); //,array('conditions' => array('Category.id' => $category_id))); 
        $data .= '<option value=""> -- Select App -- </option>';
        foreach ($applications as $application) {
            $data .= '<option value="' . $application['Applications']['app_code'] . '">' . $application['Applications']['name'] . '</option>';
        }
        echo $data;
        exit;
    }

    function get_partner_wise() {
        $acc_id = $this->request->data['partners_acc_id'];
        $app_code = $this->request->data['partners_app_id'];
        $data = "";
        $AdsPartnerWises = $this->AdsPartnerWises->find('all', array('conditions' => array('AND' => array('AdsPartnerWises.app_code' => $app_code), array('AdsPartnerWises.acc_id' => $acc_id))));
        if (count($AdsPartnerWises) == 0) {
            echo 'sorry';
            exit;
        }
        $response = [];
        if (count($AdsPartnerWises) > 0) {
            $data .= '<option value=""> -- Select Partner -- </option>';
            foreach ($AdsPartnerWises as $parnter) {
                $AdsPartnerWises_id = $parnter['AdsPartnerWises']['google_fullad'];

                $partner_name = $parnter['AdPartner']['name'];
                $data .= '<option value="' . $parnter['AdPartner']['id'] . '">' . $parnter['AdPartner']['name'] . '</option>';
            }
        }
        echo $data;
        exit;
    }

    function update_status() {
        $id = $this->request->data['id'];
        unset($this->request->data['id']);
        $this->request->data['IpAds']['status'] = $this->request->data['status_val'];
        unset($this->request->data['status_val']);

        if (!$this->IpAds->exists($id)) {
            throw new NotFoundException(__('Invalid Ad'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->request->data['IpAds']['id'] = $id;
            //echo "<pre>";print_r($this->request->data);exit;
            if ($this->IpAds->save($this->request->data)) {
                echo 1;
            } else {
                echo 2;
            }
        }
        exit;
    }

    function edit_partner() {
        $ad_partner = $this->request->data['partner_id'];
        $acc_id = $this->request->data['partner_acc_id'];
        $app_code = $this->request->data['partner_app_id'];
        $type = $this->request->data['partner_type'];

        echo $ad_partner;

        exit;
    }

    function get_partner() {
        $ad_partner = ($this->request->data['partner_id']) ? $this->request->data['partner_id'] : NULL;
        $acc_id = $this->request->data['partner_acc_id'];
        $app_code = $this->request->data['partner_app_id'];
        $type = $this->request->data['partner_type'];

        $if_exits_apps = $this->Applications->find('first', array('conditions' => array('AND' => array('Applications.app_code' => $app_code), array('Applications.account_id' => $acc_id))));
        if (count($if_exits_apps) > 0) {
            $if_exits = $this->AdsPartnerWises->find('first', array('conditions' => array('AND' => array('AdsPartnerWises.app_code' => $app_code), array('AdsPartnerWises.acc_id' => $acc_id), array('AdsPartnerWises.ad_partner' => $ad_partner))));
            if (count($if_exits) > 0) {
                foreach ($if_exits as $Ad) {
                    if ($type == 1) {
                        echo trim($Ad['google_app_id']);
                        exit;
                    } else if ($type == 2) {
                        echo trim($Ad['google_appopen']);
                        exit;
                    } else if ($type == 3) {
                        echo trim($Ad['google_fullad']);
                        exit;
                    } else if ($type == 4) {
                        echo trim($Ad['google_fullad_splash']);
                        exit;
                    } else if ($type == 5) {
                        echo trim($Ad['google_reward_ad']);
                        exit;
                    } else if ($type == 6) {
                        echo trim($Ad['google_banner']);
                        exit;
                    } else if ($type == 7) {
                        echo trim($Ad['google_native']);
                        exit;
                    } else if ($type == 8) {
                        echo trim($Ad['google_native_banner']);
                        exit;
                    }
                }
            } else {
                echo 'Not Exits';
                exit;
            }
        } else {
            echo 'Please choose account and apps';
            exit;
        }

        exit;
    }

    function selected_partner() {
        $txt_val = ($this->request->data['txt_vl']) ? $this->request->data['txt_vl'] : NULL;
        $acc_id = $this->request->data['partner_acc_id'];
        $app_code = $this->request->data['partner_app_id'];
        $type = $this->request->data['partner_type'];

        $if_exits_apps = $this->Applications->find('first', array('conditions' => array('AND' => array('Applications.app_code' => $app_code), array('Applications.account_id' => $acc_id))));
        if (count($if_exits_apps) > 0) {

            if ($type == 1) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_app_id' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_app_id']);
                    exit;
                } else {
                    echo 1;
                    exit;
                }
            } else if ($type == 2) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_appopen' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_appopen']);
                    exit;
                } else {
                    echo 2;
                    exit;
                }
            } else if ($type == 3) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_fullad' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_fullad']);
                    exit;
                } else {
                    echo 3;
                    exit;
                }
            } else if ($type == 4) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_fullad_splash' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_fullad_splash']);
                    exit;
                } else {
                    echo 4;
                    exit;
                }
            } else if ($type == 5) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_reward_ad' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_reward_ad']);
                    exit;
                } else {
                    echo 5;
                    exit;
                }
            } else if ($type == 6) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_banner' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_banner']);
                    exit;
                } else {
                    echo 6;
                    exit;
                }
            } else if ($type == 7) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_native' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_native']);
                    exit;
                } else {
                    echo 7;
                    exit;
                }
            } else if ($type == 8) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_native_banner' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_native_banner']);
                    exit;
                } else {
                    echo 8;
                    exit;
                }
            }
        } else {
            echo 'Please choose account and apps';
            exit;
        }

        exit;
    }

}
