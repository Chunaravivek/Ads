
<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

class AdsPartnerWisesController extends AppController {

    public $uses = array('AdIds', 'Applications', 'Accounts', 'AdPartner', 'AdsPartnerWises');

    public function index() {

        $description = 'Manage AdsPartnerWises';
        $keywords = 'Manage AdsPartnerWises';
        $this->set(compact('keywords', 'description'));

        $accounts = $this->Accounts->find('all');

        $this->set("accounts", $accounts);

        $ad_partner = $this->AdPartner->find('all');

        $this->set('ad_partners', $ad_partner);

        $applications = $this->Applications->find('all');

        $this->set('applications', $applications);

        $ads_ids = $this->AdIds->find('all');

        $this->set('ads_ids', $ads_ids);
    }

    public function records() {

        if (isset($this->request->query['sidx']) && $this->request->query['sidx'] != NULL)
            $order = "AdsPartnerWises." . $this->request->query['sidx'] . " " . $this->request->query['sord'] . "";
        else {
            $order = "AdsPartnerWises.modified_date DESC";
        }

        $conditions = '1=1 AND ';

        if (isset($this->params->query['account_id']) && $this->params->query['account_id'] != NULL) {

            $ac = $this->params->query['account_id'];
            $conditions .= "AdsPartnerWises.acc_id = $ac AND ";
        }
        if (isset($this->params->query['ad_partner']) && $this->params->query['ad_partner'] != NULL) {

            $part = $this->params->query['ad_partner'];
            $conditions .= "AdsPartnerWises.ad_partner = $part AND ";
        }

        if (isset($this->request->query['filters']) && $this->request->query['filters'] != '') {
            $filters = json_decode($this->request->query['filters']);
            $conditions = '';
            foreach ($filters->rules as $filter) {
                if ($filter->op == 'eq') {
                    $conditions .= "`AdsPartnerWises." . $filter->field . "` = '$filter->data' AND ";
                } elseif ($filter->op == 'ne') {
                    $conditions .= "`AdsPartnerWises." . $filter->field . "` !='$filter->data' AND ";
                } elseif ($filter->op == 'bw') {
                    $conditions .= "`AdsPartnerWises." . $filter->field . "` Like '$filter->data%' AND ";
                } elseif ($filter->op == 'bn') {
                    $conditions .= "`AdsPartnerWises." . $filter->field . "` NOT Like '$filter->data%' AND ";
                } elseif ($filter->op == 'ew') {
                    $conditions .= "`AdsPartnerWises." . $filter->field . "` Like '%$filter->data' AND ";
                } elseif ($filter->op == 'en') {
                    $conditions .= "`AdsPartnerWises." . $filter->field . "` NOT Like '%$filter->data' AND ";
                } elseif ($filter->op == 'cn') {
                    $conditions .= "`AdsPartnerWises." . $filter->field . "` Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'nc') {
                    $conditions .= "`AdsPartnerWises." . $filter->field . "` NOT Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'in') {
                    $conditions .= "`AdsPartnerWises." . $filter->field . "` IN ($filter->data) AND ";
                } elseif ($filter->op == 'ni') {
                    $conditions .= "`AdsPartnerWises." . $filter->field . "` NOT IN ($filter->data) AND ";
                }
            }
        }

        $i = 0;
        $result = array();

        if (isset($this->request->query['page']) && $this->request->query['page'] != '') {
            $result['page'] = (int) $this->request->query['page'];
        } else {
            $result['page'] = 1;
        }

        $conditions = substr($conditions, 0, -4);

        if (isset($this->request->query['rows']) && $this->request->query['rows'] != '') {
            $limit = (int) $this->request->query['rows'];
        } else {
            $limit = 10;
        }

        $offset = ($result['page'] - 1) * $limit;

        $keys = $this->AdsPartnerWises->find('all', array('conditions' => array($conditions), 'order' => $order, 'limit' => $limit, 'offset' => $offset));

        $counts = $this->AdsPartnerWises->find('count', array('conditions' => array($conditions), 'order' => $order));

        if ($counts > 0) {
            $result['total'] = ceil($counts / $limit);
        } else {
            $result['total'] = 0;
        }

        $result['records'] = $counts;


        foreach ($keys as $key) {

            $app = $this->Applications->find('first', array('conditions' => array('Applications.app_code' => $key['AdsPartnerWises']['app_code'])));
            $adpartners = $this->AdPartner->find('first', array('conditions' => array('AdPartner.id' => $key['AdsPartnerWises']['ad_partner'])));

            $play_store = isset($app['Applications']['play_store']) ? $app['Applications']['play_store'] : '';
            $package_name = isset($app['Applications']['package_name']) ? $app['Applications']['package_name'] : '';
            $app_name = isset($app['Applications']['name']) ? $app['Applications']['name'] : '';
            $ac_name = isset($app['Accounts']['name']) ? $app['Accounts']['name'] : '';
            $partner_name = isset($adpartners['AdPartner']['name']) ? $adpartners['AdPartner']['name'] : '';

            $result['rows'][$i]['id'] = $key['AdsPartnerWises']['id'];
            $result['rows'][$i]['cell'] = array(
                '',
                $key['AdsPartnerWises']['id'],
                $ac_name,
                $app_name,
                $partner_name,
                $key['AdsPartnerWises']['app_code'],
                $package_name,
                $play_store,
                date('d/m/Y', $key['AdsPartnerWises']['created_date']),
                date('d/m/Y h:i:s A', $key['AdsPartnerWises']['modified_date']),
                $key['AdsPartnerWises']['status'],
            );
            $i++;
        }

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    public function add() {
        $adids_arr = [];
        if ($this->request->is('post')) {
            $this->AdsPartnerWises->create();

            $post_arr = array_map('trim', $this->request->data['AdsPartnerWises']);

            $adids_arr['AdsPartnerWises'] = $post_arr;
            $checkcode = $this->AdsPartnerWises->find('all', array('conditions' => array('AND' => array('AdsPartnerWises.app_code' => $adids_arr['AdsPartnerWises']['app_code']),
                    array('AdsPartnerWises.ad_partner' => $adids_arr['AdsPartnerWises']['ad_partner']))));

            if (empty($checkcode)) {

                $adids_arr['AdsPartnerWises']['status'] = 1;
                $adids_arr['AdsPartnerWises']['created_date'] = time();
                $adids_arr['AdsPartnerWises']['modified_date'] = time();

                if ($this->AdsPartnerWises->save($adids_arr)) {
                    $this->Session->setFlash(__('AdsPartnerWises has been Add successfully'), 'swift_success');
                    return $this->redirect(array('controller' => 'AdsPartnerWises', 'action' => 'index'));
                } else {
                    $this->Session->setFlash(__("Unable to pasword AdsPartnerWises"), 'swift_failure');
                    return $this->redirect(array('action' => 'index'));
                }
            } else {
                $this->Session->setFlash(__($adids_arr['AdsPartnerWises']['app_code'] . " Already exists app_code"), 'swift_failure');
                return $this->redirect(array('action' => 'index'));
            }
        }

        $account = $this->Accounts->find('list');
        $this->set('accounts', $account);

        $ad_partner = $this->AdPartner->find('list');
        $this->set('ad_partners', $ad_partner);

        $applications = $this->Applications->find('list', array('conditions' => array('Applications.play_store !=' => 3)));
        $this->set('applications', $applications);
    }

    public function edit($id = NULL) {
        $id = $this->request->params['pass'][0];
        $this->AdsPartnerWises->id = $id;

        if ($this->AdsPartnerWises->exists($this->AdsPartnerWises->id)) {
            $edit_arr = [];
            if ($this->request->is('post') || $this->request->is('put')) {

                $post_arr = array_map('trim', $this->request->data['AdsPartnerWises']);

                $edit_arr['AdsPartnerWises'] = $post_arr;
                $edit_arr['AdsPartnerWises']['modified_date'] = time();

                if ($this->AdsPartnerWises->save($edit_arr)) {
                    $this->Session->setFlash(__('AdsPartnerWises has been Updated successfully'), 'swift_success');
                    return $this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(__("Unable to Add AdsPartnerWises"), 'swift_failure');
                    return $this->redirect(array('action' => 'add'));
                }
            } else {
                if (!$this->AdsPartnerWises->exists($id)) {
                    throw new NotFoundException(__('Invalid AdsPartnerWises'));
                }

                $options = array('conditions' => array('AdsPartnerWises.' . $this->AdsPartnerWises->primaryKey => $id));
                $this->request->data = $this->AdsPartnerWises->find('first', $options);

                $account = $this->Accounts->find('list');
                $this->set('accounts', $account);

                $ad_partner = $this->AdPartner->find('list');
                $this->set('ad_partners', $ad_partner);

                $app_arr = $this->Applications->find('all', array('conditions' => array('Applications.play_store !=' => 3)));

                $app_list = array();
                foreach ($app_arr as $app) {
                    $app_code = $app['Applications']['app_code'];
                    $app_name = $app['Applications']['name'];
                    $app_list[$app_code] = $app_name;
                }

                $this->set("applications", $app_list);


                $this->set('id', $this->request->data['AdsPartnerWises']['id']);
            }
        } else {
            $this->Session->setFlash(__("Not Exists Id in AdsPartnerWises"), 'swift_failure');
            return $this->redirect(array('action' => 'index'));
        }
    }

    public function inline() {

        $data = array();

        if (!empty($this->request->data) && $this->request->data['oper'] == 'edit') {
            $data['AdsPartnerWises'] = $this->request->data;
            $data['AdsPartnerWises']['modified_date'] = time();
            if ($this->AdsPartnerWises->save($data['AdsPartnerWises'])) {
                echo TRUE;
                exit;
            } else {
                echo FALSE;
                exit;
            }
        }

        if (!empty($this->request->data) && $this->request->data['oper'] == 'del') {
            $id_arr = explode(',', $this->request->data['id']);

            foreach ($id_arr as $del_id) {

                $this->AdsPartnerWises->delete($del_id);
            }
            exit;
        }
    }

    public function update_status() {
        $id = $this->request->data['id'];
        unset($this->request->data['id']);
        $this->request->data['AdsPartnerWises']['status'] = $this->request->data['status_val'];
        unset($this->request->data['status_val']);

        if (!$this->AdsPartnerWises->exists($id)) {
            throw new NotFoundException(__('Invalid AdsPartnerWises'));
        }

        if ($this->request->is('post') || $this->request->is('put')) {

            $this->request->data['AdsPartnerWises']['id'] = $id;
            if ($this->AdsPartnerWises->save($this->request->data)) {
                echo 1;
            } else {
                echo 2;
            }
        }
        exit;
    }

    function get_application() {
        $ac_id = $_REQUEST['ac_id'];
        $data = "";
        $applications = $this->Applications->find('all', array('conditions' => array('Applications.account_id' => $ac_id, 'Applications.play_store !=' => 3))); //,array('conditions' => array('Category.id' => $category_id))); 
        $data .= '<option value=""> -- Select App -- </option>';
        foreach ($applications as $application) {
            $data .= '<option value="' . $application['Applications']['app_code'] . '">' . $application['Applications']['name'] . '</option>';
        }
        echo $data;
        exit;
    }

    public function AllIfFieldCheck() {
        $response = [];
        $response['code'] = 0;
        $response['message'] = '';

        $this->if_exstis_google_appopen($this->request->data, $response);
        $this->if_exstis_google_fullad($this->request->data, $response);
        $this->if_exstis_google_fullad_splash($this->request->data, $response);
        $this->if_exstis_google_reward_ad($this->request->data, $response);
        $this->if_exstis_google_banner($this->request->data, $response);
        $this->if_exstis_google_native($this->request->data, $response);
        $this->if_exstis_google_native_banner($this->request->data, $response);

        header('Content-Type: application/json');
        $response['code'] = 200;
        echo json_encode($response);
        exit;
    }

    public function if_exstis_google_appopen($datas, $response) {

        $google_appopen = isset($datas['google_appopen']) ? trim($datas['google_appopen']) : '';
        $id = isset($datas['id']) ? $datas['id'] : '';
        $app_code = isset($datas['app_code']) ? $datas['app_code'] : '';
        $ad_partner = isset($datas['ad_partner']) ? $datas['ad_partner'] : '';

        /* google_appopen S */
        $if_google_appopens = $this->AdsPartnerWises->find('all', array('conditions' => array('AdsPartnerWises.google_appopen' => $google_appopen, 'AdsPartnerWises.id !=' => $id, 'AdsPartnerWises.app_code' => $app_code, 'AdsPartnerWises.ad_partner' => $ad_partner)));

        if (count($if_google_appopens) == 0) {

            $response['code'] = 200;
        } else {

            $response['code'] = 201;
            $response['message'] = 'google_appopen';

            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }
        /* google_appopen E */
    }

    public function if_exstis_google_fullad($datas, $response) {

        $response = [];
        $response['code'] = 0;
        $response['message'] = '';

        $google_fullad = isset($datas['google_fullad']) ? trim($datas['google_fullad']) : '';
        $id = isset($datas['id']) ? $datas['id'] : '';
        $app_code = isset($datas['app_code']) ? $datas['app_code'] : '';
        $ad_partner = isset($datas['ad_partner']) ? $datas['ad_partner'] : '';

        /* google_fullad S */
        $if_google_fullad = $this->AdsPartnerWises->find('all', array('conditions' => array('AdsPartnerWises.google_fullad' => $google_fullad, 'AdsPartnerWises.id !=' => $id, 'AdsPartnerWises.app_code' => $app_code, 'AdsPartnerWises.ad_partner' => $ad_partner)));

        if (count($if_google_fullad) == 0) {

            $response['code'] = 200;
        } else {
            $response['code'] = 201;
            $response['message'] = 'google_fullad';

            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }
        /* google_fullad E */
    }

    public function if_exstis_google_fullad_splash($datas, $response) {
        $response = [];
        $response['code'] = 0;
        $response['message'] = '';

        $google_fullad_splash = isset($datas['google_fullad_splash']) ? trim($datas['google_fullad_splash']) : '';
        $id = isset($datas['id']) ? $datas['id'] : '';
        $app_code = isset($datas['app_code']) ? $datas['app_code'] : '';
        $ad_partner = isset($datas['ad_partner']) ? $datas['ad_partner'] : '';

        /* google_fullad_splash S */
        $if_google_fullad_splash = $this->AdsPartnerWises->find('all', array('conditions' => array('AdsPartnerWises.google_fullad_splash' => $google_fullad_splash, 'AdsPartnerWises.id !=' => $id, 'AdsPartnerWises.app_code' => $app_code, 'AdsPartnerWises.ad_partner' => $ad_partner)));

        if (count($if_google_fullad_splash) == 0) {
            $response['code'] = 200;
        } else {
            $response['code'] = 201;
            $response['message'] = 'google_fullad_splash';

            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }
        /* google_fullad_splash E */
    }

    public function if_exstis_google_reward_ad($datas, $response) {
        $response = [];
        $response['code'] = 0;
        $response['message'] = '';

        $google_reward_ad = isset($datas['google_reward_ad']) ? trim($datas['google_reward_ad']) : '';
        $id = isset($datas['id']) ? $datas['id'] : '';
        $app_code = isset($datas['app_code']) ? $datas['app_code'] : '';
        $ad_partner = isset($datas['ad_partner']) ? $datas['ad_partner'] : '';

        /* google_reward_ad S */
        $if_google_reward_ad = $this->AdsPartnerWises->find('all', array('conditions' => array('AdsPartnerWises.google_reward_ad' => $google_reward_ad, 'AdsPartnerWises.id !=' => $id, 'AdsPartnerWises.app_code' => $app_code, 'AdsPartnerWises.ad_partner' => $ad_partner)));

        if (count($if_google_reward_ad) == 0) {
            $response['code'] = 200;
        } else {
            $response['code'] = 201;
            $response['message'] = 'google_reward_ad';

            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }
        /* google_reward_ad E */
    }

    public function if_exstis_google_banner($datas, $response) {
        $response = [];
        $response['code'] = 0;
        $response['message'] = '';

        $google_banner = isset($datas['google_banner']) ? trim($datas['google_banner']) : '';
        $id = isset($datas['id']) ? $datas['id'] : '';
        $app_code = isset($datas['app_code']) ? $datas['app_code'] : '';
        $ad_partner = isset($datas['ad_partner']) ? $datas['ad_partner'] : '';

        /* google_banner S */
        $if_google_banner = $this->AdsPartnerWises->find('all', array('conditions' => array('AdsPartnerWises.google_banner' => $google_banner, 'AdsPartnerWises.id !=' => $id, 'AdsPartnerWises.app_code' => $app_code, 'AdsPartnerWises.ad_partner' => $ad_partner)));

        if (count($if_google_banner) == 0) {
            $response['code'] = 200;
        } else {
            $response['code'] = 201;
            $response['message'] = 'google_banner';

            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }
        /* google_banner E */
    }

    public function if_exstis_google_native($datas, $response) {
        $response = [];
        $response['code'] = 0;
        $response['message'] = '';

        $google_native = isset($datas['google_native']) ? trim($datas['google_native']) : '';
        $id = isset($datas['id']) ? $datas['id'] : '';
        $app_code = isset($datas['app_code']) ? $datas['app_code'] : '';
        $ad_partner = isset($datas['ad_partner']) ? $datas['ad_partner'] : '';

        /* google_native S */
        $if_google_native = $this->AdsPartnerWises->find('all', array('conditions' => array('AdsPartnerWises.google_native' => $google_native, 'AdsPartnerWises.id !=' => $id, 'AdsPartnerWises.app_code' => $app_code, 'AdsPartnerWises.ad_partner' => $ad_partner)));

        if (count($if_google_native) == 0) {
            $response['code'] = 200;
        } else {
            $response['code'] = 201;
            $response['message'] = 'google_native';

            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }
        /* google_native E */
    }

    public function if_exstis_google_native_banner($datas, $response) {
        $response = [];
        $response['code'] = 0;
        $response['message'] = '';

        $google_native_banner = isset($datas['google_native_banner']) ? trim($datas['google_native_banner']) : '';
        $id = isset($datas['id']) ? $datas['id'] : '';
        $app_code = isset($datas['app_code']) ? $datas['app_code'] : '';
        $ad_partner = isset($datas['ad_partner']) ? $datas['ad_partner'] : '';

        /* google_native_banner S */
        $if_google_native_banner = $this->AdsPartnerWises->find('all', array('conditions' => array('AdsPartnerWises.google_native_banner' => $google_native_banner, 'AdsPartnerWises.id !=' => $id, 'AdsPartnerWises.app_code' => $app_code, 'AdsPartnerWises.ad_partner' => $ad_partner)));

        if (count($if_google_native_banner) == 0) {
            $response['code'] = 200;
        } else {
            $response['code'] = 201;
            $response['message'] = 'google_native_banner';

            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }
        /* google_native_banner E */
    }

}
