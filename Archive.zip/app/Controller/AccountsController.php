
<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

class AccountsController extends AppController {

    public $uses = array('Accounts');

    public function index() {
        $description = 'Manage Accounts';
        $keywords = 'Manage Accounts';
        $this->set(compact('keywords', 'description'));
    }

    public function records() {
        if (isset($this->request->query['sidx']) && $this->request->query['sidx'] != NULL)
            $order = "Accounts." . $this->request->query['sidx'] . " " . $this->request->query['sord'] . "";
        else {
            $order = "Accounts.modified_date DESC";
        }

        $conditions = '1=1 ';

        if (isset($this->request->query['filters']) && $this->request->query['filters'] != '') {
            $filters = json_decode($this->request->query['filters']);
            $conditions = '';
            foreach ($filters->rules as $filter) {
                if ($filter->op == 'eq') {
                    $conditions .= "`Accounts." . $filter->field . "` = '$filter->data' AND ";
                } elseif ($filter->op == 'ne') {
                    $conditions .= "`Accounts." . $filter->field . "` !='$filter->data' AND ";
                } elseif ($filter->op == 'bw') {
                    $conditions .= "`Accounts." . $filter->field . "` Like '$filter->data%' AND ";
                } elseif ($filter->op == 'bn') {
                    $conditions .= "`Accounts." . $filter->field . "` NOT Like '$filter->data%' AND ";
                } elseif ($filter->op == 'ew') {
                    $conditions .= "`Accounts." . $filter->field . "` Like '%$filter->data' AND ";
                } elseif ($filter->op == 'en') {
                    $conditions .= "`Accounts." . $filter->field . "` NOT Like '%$filter->data' AND ";
                } elseif ($filter->op == 'cn') {
                    $conditions .= "`Accounts." . $filter->field . "` Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'nc') {
                    $conditions .= "`Accounts." . $filter->field . "` NOT Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'in') {
                    $conditions .= "`Accounts." . $filter->field . "` IN ($filter->data) AND ";
                } elseif ($filter->op == 'ni') {
                    $conditions .= "`Accounts." . $filter->field . "` NOT IN ($filter->data) AND ";
                }
            }
        }

        $i = 0;
        $result = array();

        if (isset($this->request->query['page']) && $this->request->query['page'] != '') {
            $result['page'] = (int) $this->request->query['page'];
        } else {
            $result['page'] = 1;
        }

        $conditions = substr($conditions, 0, -4);

        if (isset($this->request->query['rows']) && $this->request->query['rows'] != '') {
            $limit = (int) $this->request->query['rows'];
        } else {
            $limit = 10;
        }

        $offset = ($result['page'] - 1) * $limit;

        $keys = $this->Accounts->find('all', array('conditions' => array($conditions), 'order' => $order, 'limit' => $limit, 'offset' => $offset));

        $counts = $this->Accounts->find('count', array('conditions' => array($conditions), 'order' => $order));

        if ($counts > 0) {
            $result['total'] = ceil($counts / $limit);
        } else {
            $result['total'] = 0;
        }

        $result['records'] = $counts;


        foreach ($keys as $key) {

            $result['rows'][$i]['id'] = $key['Accounts']['id'];
            $result['rows'][$i]['cell'] = array(
                '',
                $key['Accounts']['id'],
                $key['Accounts']['name'],
                date('d/m/Y', $key['Accounts']['created_date']),
                date('d/m/Y h:i:s A', $key['Accounts']['modified_date']),
                $key['Accounts']['status'],
            );
            $i++;
        }

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    public function add() {
        if ($this->request->is('post')) {
            $this->Accounts->create();

            $this->request->data['Accounts']['status'] = 1;
            $this->request->data['Accounts']['created_date'] = time();
            $this->request->data['Accounts']['modified_date'] = time();
            
            if ($this->Accounts->save($this->request->data)) {
                $this->Session->setFlash(__('Accounts has been Add successfully'), 'swift_success');
                return $this->redirect(array('controller' => 'Accounts', 'action' => 'index'));
            } else {
                $this->Session->setFlash(__("Unable to pasword Accounts"), 'swift_failure');
                return $this->redirect(array('action' => 'index'));
            }
        }
    }

    public function edit($id = NULL) {
        $id = $this->request->params['pass'][0];
        $this->Accounts->id = $id;

        if ($this->Accounts->exists($this->Accounts->id)) {
            if ($this->request->is('post') || $this->request->is('put')) {
                $this->request->data['Accounts']['modified_date'] = time();

                if ($this->Accounts->save($this->request->data)) {
                    $this->Session->setFlash(__('Accounts has been Updated successfully'), 'swift_success');
                    return $this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(__("Unable to Add Accounts"), 'swift_failure');
                    return $this->redirect(array('action' => 'add'));
                }
            } else {
                if (!$this->Accounts->exists($id)) {
                    throw new NotFoundException(__('Invalid Accounts'));
                }

                $options = array('conditions' => array('Accounts.' . $this->Accounts->primaryKey => $id));
                $this->request->data = $this->Accounts->find('first', $options);


                $this->set('id', $this->request->data['Accounts']['id']);
            }
        } else {
            $this->Session->setFlash(__("Not Exists Id in Accounts"), 'swift_failure');
            return $this->redirect(array('action' => 'index'));
        }
    }

    public function inline() {

        $data = array();

        if (!empty($this->request->data) && $this->request->data['oper'] == 'edit') {
            $data['Accounts'] = $this->request->data;
            $data['Accounts']['modified_date'] = time();
            if ($this->Accounts->save($data['Accounts'])) {
                echo TRUE;
                exit;
            } else {
                echo FALSE;
                exit;
            }
        }

        if (!empty($this->request->data) && $this->request->data['oper'] == 'del') {
            $id_arr = explode(',', $this->request->data['id']);

            foreach ($id_arr as $del_id) {

                $this->Accounts->delete($del_id);
            }
            exit;
        }
    }

    public function update_status() {
        $id = $this->request->data['id'];
        unset($this->request->data['id']);
        $this->request->data['Accounts']['status'] = $this->request->data['status_val'];
        unset($this->request->data['status_val']);

        if (!$this->Accounts->exists($id)) {
            throw new NotFoundException(__('Invalid Accounts'));
        }

        if ($this->request->is('post') || $this->request->is('put')) {

            $this->request->data['Accounts']['id'] = $id;
            if ($this->Accounts->save($this->request->data)) {
                echo 1;
            } else {
                echo 2;
            }
        }
        exit;
    }

    public function IfExitstNames() {

        $name = trim($this->request->data['name']);
        unset($this->request->data['name']);

        if (isset($this->request->data['id']) && $name != NULL) {
            $id = $this->request->data['id'];
            $ifname = $this->Accounts->find('count', array('conditions' => array('Accounts.name' => $name, ' Accounts.id !=' => $id)));
        } else {
            $ifname = $this->Accounts->find('count', array('conditions' => array('Accounts.name' => $name)));
        }

        $response = [];
        $response['code'] = 0;

        if (isset($ifname) && $ifname > 0) {
            $response['code'] = 201;
        } else {
            $response['code'] = 200;
        }

        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

}
