<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

/**
 * CakePHP DashboardController
 * @author s4
 */
class DashboardController extends AppController {

    public $uses = array('Admin');

    public function index() {
        $description = 'Manage Dashboard';
        $keywords = 'Manage Dashboard';
        $this->set(compact('keywords', 'description'));

        $admin = $this->Admin->find('count');
        $this->set('admin_count', $admin);
    }

}
