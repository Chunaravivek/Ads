
<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

class CitiesController extends AppController {

    public $uses = array('Cities');

    public function index() {
        $description = 'Manage Cities';
        $keywords = 'Manage Cities';
        $this->set(compact('keywords', 'description'));
    }

    public function records() {
       
        if (isset($this->request->query['sidx']) && $this->request->query['sidx'] != NULL)
            $order = "Cities." . $this->request->query['sidx'] . " " . $this->request->query['sord'] . "";
        else {
            $order = "Cities.modified_date DESC";
        }

        $conditions = '1=1 AND ';

        if (isset($this->params->query['type_id']) && $this->params->query['type_id'] != NULL) {

            $type_id = $this->params->query['type_id'];

            $conditions .= " Cities.type_id = $type_id AND ";
        }

        if (isset($this->request->query['filters']) && $this->request->query['filters'] != '') {
            $filters = json_decode($this->request->query['filters']);
            $conditions = '';
            foreach ($filters->rules as $filter) {
                if ($filter->op == 'eq') {
                    $conditions .= "`Cities." . $filter->field . "` = '$filter->data' AND ";
                } elseif ($filter->op == 'ne') {
                    $conditions .= "`Cities." . $filter->field . "` !='$filter->data' AND ";
                } elseif ($filter->op == 'bw') {
                    $conditions .= "`Cities." . $filter->field . "` Like '$filter->data%' AND ";
                } elseif ($filter->op == 'bn') {
                    $conditions .= "`Cities." . $filter->field . "` NOT Like '$filter->data%' AND ";
                } elseif ($filter->op == 'ew') {
                    $conditions .= "`Cities." . $filter->field . "` Like '%$filter->data' AND ";
                } elseif ($filter->op == 'en') {
                    $conditions .= "`Cities." . $filter->field . "` NOT Like '%$filter->data' AND ";
                } elseif ($filter->op == 'cn') {
                    $conditions .= "`Cities." . $filter->field . "` Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'nc') {
                    $conditions .= "`Cities." . $filter->field . "` NOT Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'in') {
                    $conditions .= "`Cities." . $filter->field . "` IN ($filter->data) AND ";
                } elseif ($filter->op == 'ni') {
                    $conditions .= "`Cities." . $filter->field . "` NOT IN ($filter->data) AND ";
                }
            }
        }

        $i = 0;
        $result = array();

        if (isset($this->request->query['page']) && $this->request->query['page'] != '') {
            $result['page'] = (int) $this->request->query['page'];
        } else {
            $result['page'] = 1;
        }

        $conditions = substr($conditions, 0, -4);

        if (isset($this->request->query['rows']) && $this->request->query['rows'] != '') {
            $limit = (int) $this->request->query['rows'];
        } else {
            $limit = 10;
        }

        $offset = ($result['page'] - 1) * $limit;

        $keys = $this->Cities->find('all', array('conditions' => array($conditions), 'order' => $order, 'limit' => $limit, 'offset' => $offset));
        
        $counts = $this->Cities->find('count', array('conditions' => array($conditions), 'order' => $order));

        if ($counts > 0) {
            $result['total'] = ceil($counts / $limit);
        } else {
            $result['total'] = 0;
        }

        $result['records'] = $counts;


        foreach ($keys as $key) {

            $result['rows'][$i]['id'] = $key['Cities']['id'];
            $result['rows'][$i]['cell'] = array(
                '',
                $key['Cities']['id'],
                $key['Cities']['name'],
                $key['Cities']['type_id'],
                date('d/m/Y', $key['Cities']['created_date']),
                date('d/m/Y h:i:s A', $key['Cities']['modified_date']),
                $key['Cities']['status'],
            );
            $i++;
        }

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    public function add() {
        if ($this->request->is('post')) {
            $this->Cities->create();

            $this->request->data['Cities']['status'] = 1;
            $this->request->data['Cities']['created_date'] = time();
            $this->request->data['Cities']['modified_date'] = time();

            if ($this->Cities->save($this->request->data)) {
                $this->Session->setFlash(__('Cities has been Add successfully'), 'swift_success');
                return $this->redirect(array('controller' => 'Cities', 'action' => 'index'));
            } else {
                $this->Session->setFlash(__("Unable to pasword Cities"), 'swift_failure');
                return $this->redirect(array('action' => 'index'));
            }
        }
    }

    public function edit($id = NULL) {
        $id = $this->request->params['pass'][0];
        $this->Cities->id = $id;

        if ($this->Cities->exists($this->Cities->id)) {
            if ($this->request->is('post') || $this->request->is('put')) {
                $this->request->data['Cities']['modified_date'] = time();

                if ($this->Cities->save($this->request->data)) {
                    $this->Session->setFlash(__('Cities has been Updated successfully'), 'swift_success');
                    return $this->redirect(array('action' => 'index'));
                } else {
                    $this->Session->setFlash(__("Unable to Add Cities"), 'swift_failure');
                    return $this->redirect(array('action' => 'add'));
                }
            } else {
                if (!$this->Cities->exists($id)) {
                    throw new NotFoundException(__('Invalid Cities'));
                }

                $options = array('conditions' => array('Cities.' . $this->Cities->primaryKey => $id));
                $this->request->data = $this->Cities->find('first', $options);


                $this->set('id', $this->request->data['Cities']['id']);
            }
        } else {
            $this->Session->setFlash(__("Not Exists Id in Cities"), 'swift_failure');
            return $this->redirect(array('action' => 'index'));
        }
    }

    public function inline() {

        $data = array();

        if (!empty($this->request->data) && $this->request->data['oper'] == 'edit') {
            $data['Cities'] = $this->request->data;
            $data['Cities']['modified_date'] = time();
            if ($this->Cities->save($data['Cities'])) {
                echo TRUE;
                exit;
            } else {
                echo FALSE;
                exit;
            }
        }

        if (!empty($this->request->data) && $this->request->data['oper'] == 'del') {
            $id_arr = explode(',', $this->request->data['id']);

            foreach ($id_arr as $del_id) {

                $this->Cities->delete($del_id);
            }
            exit;
        }
    }

    public function update_status() {
        $id = $this->request->data['id'];
        unset($this->request->data['id']);
        $this->request->data['Cities']['status'] = $this->request->data['status_val'];
        unset($this->request->data['status_val']);

        if (!$this->Cities->exists($id)) {
            throw new NotFoundException(__('Invalid Cities'));
        }

        if ($this->request->is('post') || $this->request->is('put')) {

            $this->request->data['Cities']['id'] = $id;
            if ($this->Cities->save($this->request->data)) {
                echo 1;
            } else {
                echo 2;
            }
        }
        exit;
    }

    public function ifcity() {

        $name = trim($this->request->data['name']);
        unset($this->request->data['name']);
        
        if (isset($this->request->data['id']) && $name != NULL) {
            $id = $this->request->data['id'];
            $ifCities = $this->Cities->find('count', array('conditions' => array('Cities.name' => $name, ' Cities.id !=' => $id)));
        } else {
            $ifCities = $this->Cities->find('count', array('conditions' => array('Cities.name' => $name)));
        }

        $response = [];
        $response['code'] = 0;

        if (isset($ifCities) && $ifCities > 0) {
            $response['code'] = 201;
        } else {
            $response['code'] = 200;
        }

        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

}
