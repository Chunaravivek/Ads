<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

/**
 * CakePHP AppRedirectsController
 * @author s4
 */
class AppRedirectsController extends AppController {

    public $uses = array('AdIds', 'IpAds');

    public function index() {
        $description = 'Manage Accounts';
        $keywords = 'Manage Accounts';
        $this->set(compact('keywords', 'description'));

        $ads = $this->AdIds->find('first');
        $this->set("ads", isset($ads['AdIds']['path']) ? $ads['AdIds']['path'] : 'https://play.google.com/store/apps/details?id=com.rc.ffskintool.freediamondemote');
    }

    public function update() {
        if ($this->request->is('post')) {
            
            $app_path = $this->request->data['AppRedirects']['app_redirect_path'];

            $this->AdIds->updateAll(array('path' => "'$app_path'"));
            
            $this->IpAds->updateAll(array('path' => "'$app_path'"));
            
            $this->Session->setFlash(__('The AppRedirects has been saved'), 'swift_success');            
            return $this->redirect(array('action' => 'index'));
        }
        
        return $this->redirect(array('action' => 'index'));
    }

}
