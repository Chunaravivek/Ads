<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

/**
 * CakePHP AdIdsController
 * @author s4ittech
 */
class AdIdsController extends AppController {

    public $uses = array('AdIds', 'Applications', 'Accounts', 'AdPartner', 'AdsPartnerWises');

    function index() {
        
        $description = 'Manage AdsPartnerWises';
        $keywords = 'Manage AdsPartnerWises';
        $this->set(compact('keywords', 'description'));

        $accounts = $this->Accounts->find('all');
        
        $this->set("accounts", $accounts);
    }

    public function records() {

        if (isset($this->request->query['sidx']) && $this->request->query['sidx'] != NULL)
            $order = "AdIds." . $this->request->query['sidx'] . " " . $this->request->query['sord'] . "";
        else {
            $order = "AdIds.modified_date DESC";
        }

        $conditions = '1=1 AND ';

        if (isset($this->params->query['account_id']) && $this->params->query['account_id'] != NULL) {

            $ac = $this->params->query['account_id'];
            $conditions .= "AdIds.acc_id = $ac AND ";
        }

        if (isset($this->request->query['filters']) && $this->request->query['filters'] != '') {
            $filters = json_decode($this->request->query['filters']);
            $conditions = '';
            foreach ($filters->rules as $filter) {
                if ($filter->op == 'eq') {
                    $conditions .= "`AdIds." . $filter->field . "` = '$filter->data' AND ";
                } elseif ($filter->op == 'ne') {
                    $conditions .= "`AdIds." . $filter->field . "` !='$filter->data' AND ";
                } elseif ($filter->op == 'bw') {
                    $conditions .= "`AdIds." . $filter->field . "` Like '$filter->data%' AND ";
                } elseif ($filter->op == 'bn') {
                    $conditions .= "`AdIds." . $filter->field . "` NOT Like '$filter->data%' AND ";
                } elseif ($filter->op == 'ew') {
                    $conditions .= "`AdIds." . $filter->field . "` Like '%$filter->data' AND ";
                } elseif ($filter->op == 'en') {
                    $conditions .= "`AdIds." . $filter->field . "` NOT Like '%$filter->data' AND ";
                } elseif ($filter->op == 'cn') {
                    $conditions .= "`AdIds." . $filter->field . "` Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'nc') {
                    $conditions .= "`AdIds." . $filter->field . "` NOT Like '%$filter->data%' AND ";
                } elseif ($filter->op == 'in') {
                    $conditions .= "`AdIds." . $filter->field . "` IN ($filter->data) AND ";
                } elseif ($filter->op == 'ni') {
                    $conditions .= "`AdIds." . $filter->field . "` NOT IN ($filter->data) AND ";
                }
            }
        }

        $i = 0;
        $result = array();

        if (isset($this->request->query['page']) && $this->request->query['page'] != '') {
            $result['page'] = (int) $this->request->query['page'];
        } else {
            $result['page'] = 1;
        }

        $conditions = substr($conditions, 0, -4);

        if (isset($this->request->query['rows']) && $this->request->query['rows'] != '') {
            $limit = (int) $this->request->query['rows'];
        } else {
            $limit = 10;
        }

        $offset = ($result['page'] - 1) * $limit;

        $keys = $this->AdIds->find('all', array('conditions' => array($conditions), 'order' => $order, 'limit' => $limit, 'offset' => $offset));

        $counts = $this->AdIds->find('count', array('conditions' => array($conditions), 'order' => $order));

        if ($counts > 0) {
            $result['total'] = ceil($counts / $limit);
        } else {
            $result['total'] = 0;
        }

        $result['records'] = $counts;

        foreach ($keys as $key) {
           
            $app = $this->Applications->find('first', array('conditions' => array('Applications.app_code' => $key['AdIds']['app_code'])));

            $app_name = isset($app['Applications']['name']) ? $app['Applications']['name'] : '';
            $ac_name = isset($app['Accounts']['name']) ? $app['Accounts']['name'] : '';

            $result['rows'][$i]['id'] = $key['AdIds']['id'];
            $result['rows'][$i]['cell'] = array(
                '',
                $key['AdIds']['id'],
                $ac_name,
                $key['AdIds']['app_name'],
                $key['AdIds']['app_code'],
                $key['AdIds']['json_path'],
                isset($app['Application']['package_name']) ? $app['Application']['package_name'] : '',
                isset($app['Application']['play_store']) ? $app['Application']['play_store'] : '',
                date('d/m/Y', $key['AdIds']['created_date']),
                date('d/m/Y h:i:s A', $key['AdIds']['modified_date']),
                $key['AdIds']['status'],
                $key['AdIds']['update_status'],
            );

            $i++;
        }

        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    function inline() {
        $data = array();
        if (!empty($this->params->data) && $this->params->data['oper'] == 'edit') {
            $data['AdIds'] = $this->params->data;
            $data['AdIds']['modified_date'] = time();
            if ($this->AdIds->save($data['AdIds'])) {
                echo TRUE;
                exit;
            } else {
                echo FALSE;
                exit;
            }
        }
        if (!empty($this->params->data) && $this->params->data['oper'] == 'del') {
            $id_arr = explode(',', $this->params->data['id']);

            foreach ($id_arr as $del_id) {

                $this->AdIds->delete($del_id);
            }exit;
        }
    }

    public function edit($id = null) {
       
        if (!$this->AdIds->exists($id)) {
            throw new NotFoundException(__('Invalid Ad id'));
        }

        $edit_data_arr = [];
        if ($this->request->is('post') || $this->request->is('put')) {
            
            $post_arr = array_map('trim', $this->request->data['AdIds']);

            $edit_data_arr['AdIds'] = $post_arr;

            $checkcode = $this->AdIds->find('first', array('conditions' => array('AdIds.app_code' => $edit_data_arr['AdIds']['app_code'], 'AdIds.id !=' => $id)));

            if (empty($checkcode)) {

                $edit_data_arr['AdIds']['id'] = $id;
                $edit_data_arr['AdIds']['modified_date'] = time();

                $app = $this->Applications->find('first', array('conditions' => array('Applications.app_code' => $edit_data_arr['AdIds']['app_code'])));

                $edit_data_arr['AdIds']['app_name'] = $app['Applications']['name'];
               
                if ($this->AdIds->save($edit_data_arr)) {
                    $this->Session->setFlash(__('AdIds has been Add successfully'), 'swift_success');
                    return $this->redirect(array('controller' => 'AdIds', 'action' => 'index'));
                } else {
                    $this->Session->setFlash(__("Unable to pasword AdIds"), 'swift_failure');
                    return $this->redirect(array('action' => 'index'));
                }
            } else {
                $this->Session->setFlash(__($edit_data_arr['AdIds']['app_code'] . " Already exists app_code"), 'swift_failure');
                return $this->redirect(array('action' => 'index'));
            }
        } else {
            $options = array('conditions' => array('AdIds.' . $this->AdIds->primaryKey => $id));
            $this->request->data = $this->AdIds->find('first', $options);

            $this->set('id', $this->request->data['AdIds']['id']);

            $anim = $this->request->data['AdIds']['anim'];
            $this->set('anim', $anim);

            $ad_call = $this->request->data['AdIds']['ad_call'];
            $this->set('ad_call', $ad_call);

            $adptive_banner = $this->request->data['AdIds']['adptive_banner'];
            $this->set('adptive_banner', $adptive_banner);

            $back_ad_set = $this->request->data['AdIds']['back_ad_set'];
            $this->set('back_ad_set', $back_ad_set);

            $exit_native_ad = $this->request->data['AdIds']['exit_native_ad'];
            $this->set('exit_native_ad', $exit_native_ad);

            $qureka_ad = $this->request->data['AdIds']['qureka_ad'];
            $this->set('qureka_ad', $qureka_ad);

            $app_status = $this->request->data['AdIds']['app_status'];
            $this->set('app_status', $app_status);

            $in_house = $this->request->data['AdIds']['in_house'];
            $this->set('in_house', $in_house);

            $ad_dialogue = $this->request->data['AdIds']['ad_dialogue'];
            $this->set('ad_dialogue', $ad_dialogue);

            $open_inter = $this->request->data['AdIds']['open_inter'];
            $this->set('open_inter', $open_inter);

            $open_inter = $this->request->data['AdIds']['open_inter'];
            $this->set('open_inter', $open_inter);

            $rec_apps = $this->request->data['AdIds']['rec_apps'];
            $this->set('rec_apps', $rec_apps);

            $native_pre_load = $this->request->data['AdIds']['native_pre_load'];
            $this->set('native_pre_load', $native_pre_load);

            $multiple_start = $this->request->data['AdIds']['multiple_start'];
            $this->set('multiple_start', $multiple_start);

            $nav_bar = $this->request->data['AdIds']['nav_bar'];
            $this->set('nav_bar', $nav_bar);

            $banner_native = $this->request->data['AdIds']['banner_native'];
            $this->set('banner_native', $banner_native);

            $vpn_detect = $this->request->data['AdIds']['vpn_detect'];
            $this->set('vpn_detect', $vpn_detect);

            $vpn_button = $this->request->data['AdIds']['vpn_button'];
            $this->set('vpn_button', $vpn_button);

            $transparent = $this->request->data['AdIds']['transparent'];
            $this->set('transparent', $transparent);

            $ad_partner = $this->AdPartner->find('list');
            $this->set('ad_partners', $ad_partner);

            $account = $this->Accounts->find('list');
            $this->set('accounts', $account);

            $app_arr = $this->Applications->find('all');

            $app_list = array();
            foreach ($app_arr as $app) {
                $app_code = $app['Applications']['app_code'];
                $app_name = $app['Applications']['name'];
                $app_list[$app_code] = $app_name;
            }
//         
            $this->set("applications", $app_list);

            $ads_id_app_code = $this->request->data['AdIds']['app_code'];
            $ads_id_acc_id = $this->request->data['AdIds']['acc_id'];

            $conditions_query = "AdsPartnerWises.app_code = '$ads_id_app_code' AND AdsPartnerWises.acc_id = $ads_id_acc_id ";
            $adsparnterwises = $this->AdsPartnerWises->find('all', array('conditions' => array($conditions_query)));

            /* google_app_id S */
            $google_app_id_select2 = array();
            foreach ($adsparnterwises as $google_app_id) {
                $AdsPartnerWises_id = $google_app_id['AdsPartnerWises']['google_app_id'];

                $partner_name = $google_app_id['AdPartner']['name'];
                $google_app_id_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_app_id', $google_app_id_select2);
            $this->set('google_app_id_val', $this->request->data['AdIds']['google_app_id']);
            /* google_app_id E */

            /* google_appopen S */
            $google_appopen_select = array();
            foreach ($adsparnterwises as $google_appopen) {

                $AdsPartnerWises_id = $google_appopen['AdsPartnerWises']['google_appopen'];

                $partner_name = $google_appopen['AdPartner']['name'];
                $google_appopen_select[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_appopen', $google_appopen_select);
            $this->set('google_appopen_val', $this->request->data['AdIds']['google_appopen']);
            /* google_appopen E */

            /* google_appopen 2 S */
            $this->set('google_appopen_2_val', $this->request->data['AdIds']['google_appopen_2']);
            /* google_appopen 2 E */

            /* google_appopen 3 S */
            $this->set('google_appopen_3_val', $this->request->data['AdIds']['google_appopen_3']);
            /* google_appopen 3 E */

            /* google_fullad S */
            $google_fullad_select2 = array();
            foreach ($adsparnterwises as $google_fullad) {
                $AdsPartnerWises_id = $google_fullad['AdsPartnerWises']['google_fullad'];

                $partner_name = $google_fullad['AdPartner']['name'];
                $google_fullad_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_fullad', $google_fullad_select2);
            $this->set('google_fullad_val', $this->request->data['AdIds']['google_fullad']);
            /* google_fullad E */

            /* google_fullad 2 S */
            $this->set('google_fullad_2_val', $this->request->data['AdIds']['google_fullad_2']);
            /* google_fullad 2 E */

            /* google_fullad 3 S */
            $this->set('google_fullad_3_val', $this->request->data['AdIds']['google_fullad_3']);
            /* google_fullad 3 E */



            /* google_fullad_splash S */
            $google_fullad_splash_select2 = array();
            foreach ($adsparnterwises as $google_fullad_splash) {
                $AdsPartnerWises_id = $google_fullad_splash['AdsPartnerWises']['google_fullad_splash'];

                $partner_name = $google_fullad_splash['AdPartner']['name'];
                $google_fullad_splash_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_fullad_splash', $google_fullad_splash_select2);
            $this->set('google_fullad_splash_val', $this->request->data['AdIds']['google_fullad_splash']);
            /* google_fullad_splash E */

            /* google_reward_ad S */
            $google_reward_ad_select2 = array();
            foreach ($adsparnterwises as $google_reward_ad) {
                $AdsPartnerWises_id = $google_reward_ad['AdsPartnerWises']['google_reward_ad'];

                $partner_name = $google_reward_ad['AdPartner']['name'];
                $google_reward_ad_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_reward_ad', $google_reward_ad_select2);
            $this->set('google_reward_ad_val', $this->request->data['AdIds']['google_reward_ad']);
            /* google_reward_ad E */

            /* google_banner S */
            $google_banner_select2 = array();
            foreach ($adsparnterwises as $google_banner) {
                $AdsPartnerWises_id = $google_banner['AdsPartnerWises']['google_banner'];

                $partner_name = $google_banner['AdPartner']['name'];
                $google_banner_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_banner', $google_banner_select2);
            $this->set('google_banner_val', $this->request->data['AdIds']['google_banner']);
            /* google_banner E */

            /* google_native S */
            $google_native_select2 = array();
            foreach ($adsparnterwises as $google_native) {
                $AdsPartnerWises_id = $google_native['AdsPartnerWises']['google_native'];

                $partner_name = $google_native['AdPartner']['name'];
                $google_native_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_native', $google_native_select2);
            $this->set('google_native_val', $this->request->data['AdIds']['google_native']);
            /* google_native E */

            /* google_native 2 S */
            $this->set('google_native_2_val', $this->request->data['AdIds']['google_native_2']);
            /* google_native 2 E */

            /* google_native 3 S */
            $this->set('google_native_3_val', $this->request->data['AdIds']['google_native_3']);
            /* google_native 3 E */

            /* google_native_banner S */
            $google_native_banner_select2 = array();
            foreach ($adsparnterwises as $google_native_banner) {
                $AdsPartnerWises_id = $google_native_banner['AdsPartnerWises']['google_native_banner'];

                $partner_name = $google_native_banner['AdPartner']['name'];
                $google_native_banner_select2[$AdsPartnerWises_id] = $partner_name;
            }

            $this->set('google_native_banner', $google_native_banner_select2);
            $this->set('google_native_banner_val', $this->request->data['AdIds']['google_native_banner']);
            /* google_native_banner E */
        }
    }

    public function add() {
        $add_data_arr = [];
        if ($this->request->is('post')) {

            $post_arr = array_map('trim', $this->request->data['AdIds']);

            $add_data_arr['AdIds'] = $post_arr;

            $checkcode = $this->AdIds->find('first', array('conditions' => array('AdIds.app_code' => $add_data_arr['AdIds']['app_code'])));

            if (empty($checkcode)) {

                $add_data_arr['AdIds']['status'] = 1;
                $add_data_arr['AdIds']['created_date'] = time();
                $add_data_arr['AdIds']['modified_date'] = time();

                $app = $this->Applications->find('first', array('conditions' => array('Applications.app_code' => $add_data_arr['AdIds']['app_code'])));

                $add_data_arr['AdIds']['app_name'] = $app['Applications']['name'];

                if ($this->AdIds->save($add_data_arr)) {
                    $this->Session->setFlash(__('AdIds has been Add successfully'), 'swift_success');
                    return $this->redirect(array('controller' => 'AdIds', 'action' => 'index'));
                } else {
                    $this->Session->setFlash(__("Unable to pasword AdIds"), 'swift_failure');
                    return $this->redirect(array('action' => 'index'));
                }
            } else {
                $this->Session->setFlash(__($add_data_arr['AdIds']['app_code'] . " Already exists app_code"), 'swift_failure');
                return $this->redirect(array('action' => 'index'));
            }
        }
      
        $account = $this->Accounts->find('list');
        $this->set('accounts', $account);

        $applications = $this->Applications->find('list');
        $this->set('applications', $applications);

        $app_path_link = $this->AdIds->find('first');
        $this->set("app_path_link", isset($app_path_link['AdIds']['path']) ? $app_path_link['AdIds']['path'] : "");

        $adsparnterwises = $this->AdsPartnerWises->find('all');
        $this->set('adsparnterwises', $adsparnterwises);
        
    }

    function get_application() {
        $ac_id = $_REQUEST['ac_id'];

        $data = "";
        $applications = $this->Applications->find('all', array('conditions' => array('Applications.account_id' => $ac_id))); //,array('conditions' => array('Category.id' => $category_id))); 
        $data .= '<option value=""> -- Select App -- </option>';
        foreach ($applications as $application) {
            $data .= '<option value="' . $application['Applications']['app_code'] . '">' . $application['Applications']['name'] . '</option>';
        }
        echo $data;
        exit;
    }

    function get_partner_wise() {
        $acc_id = $this->request->data['partners_acc_id'];
        $app_code = $this->request->data['partners_app_id'];
        $data = "";
        $AdsPartnerWises = $this->AdsPartnerWises->find('all', array('conditions' => array('AND' => array('AdsPartnerWises.app_code' => $app_code), array('AdsPartnerWises.acc_id' => $acc_id))));
        if (count($AdsPartnerWises) == 0) {
            echo 'sorry';
            exit;
        }
        $response = [];
        if (count($AdsPartnerWises) > 0) {
            $data .= '<option value=""> -- Select Partner -- </option>';
            foreach ($AdsPartnerWises as $parnter) {
                $AdsPartnerWises_id = $parnter['AdsPartnerWises']['google_fullad'];

                $partner_name = $parnter['AdPartner']['name'];
                $data .= '<option value="' . $parnter['AdPartner']['id'] . '">' . $parnter['AdPartner']['name'] . '</option>';
            }
        }
        echo $data;
        exit;
    }

    function update_status() {
        $id = $this->request->data['id'];
        unset($this->request->data['id']);
        $this->request->data['AdIds']['status'] = $this->request->data['status_val'];
        unset($this->request->data['status_val']);

        if (!$this->AdIds->exists($id)) {
            throw new NotFoundException(__('Invalid Ad'));
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->request->data['AdIds']['id'] = $id;
            //echo "<pre>";print_r($this->request->data);exit;
            if ($this->AdIds->save($this->request->data)) {
                echo 1;
            } else {
                echo 2;
            }
        }
        exit;
    }

    function edit_partner() {
        $ad_partner = $this->request->data['partner_id'];
        $acc_id = $this->request->data['partner_acc_id'];
        $app_code = $this->request->data['partner_app_id'];
        $type = $this->request->data['partner_type'];

        echo $ad_partner;

        exit;
    }

    function get_partner() {
        $ad_partner = ($this->request->data['partner_id']) ? $this->request->data['partner_id'] : NULL;
        $acc_id = $this->request->data['partner_acc_id'];
        $app_code = $this->request->data['partner_app_id'];
        $type = $this->request->data['partner_type'];

        $if_exits_apps = $this->Applications->find('first', array('conditions' => array('AND' => array('Applications.app_code' => $app_code), array('Applications.account_id' => $acc_id))));
        if (count($if_exits_apps) > 0) {
            $if_exits = $this->AdsPartnerWises->find('first', array('conditions' => array('AND' => array('AdsPartnerWises.app_code' => $app_code), array('AdsPartnerWises.acc_id' => $acc_id), array('AdsPartnerWises.ad_partner' => $ad_partner))));
            if (count($if_exits) > 0) {
                foreach ($if_exits as $Ad) {
                    if ($type == 1) {
                        echo trim($Ad['google_app_id']);
                        exit;
                    } else if ($type == 2) {
                        echo trim($Ad['google_appopen']);
                        exit;
                    } else if ($type == 3) {
                        echo trim($Ad['google_fullad']);
                        exit;
                    } else if ($type == 4) {
                        echo trim($Ad['google_fullad_splash']);
                        exit;
                    } else if ($type == 5) {
                        echo trim($Ad['google_reward_ad']);
                        exit;
                    } else if ($type == 6) {
                        echo trim($Ad['google_banner']);
                        exit;
                    } else if ($type == 7) {
                        echo trim($Ad['google_native']);
                        exit;
                    } else if ($type == 8) {
                        echo trim($Ad['google_native_banner']);
                        exit;
                    }
                }
            } else {
                echo 'Not Exits';
                exit;
            }
        } else {
            echo 'Please choose account and apps';
            exit;
        }

        exit;
    }

    function selected_partner() {
        $txt_val = ($this->request->data['txt_vl']) ? $this->request->data['txt_vl'] : NULL;
        $acc_id = $this->request->data['partner_acc_id'];
        $app_code = $this->request->data['partner_app_id'];
        $type = $this->request->data['partner_type'];

        $if_exits_apps = $this->Applications->find('first', array('conditions' => array('AND' => array('Applications.app_code' => $app_code), array('Applications.account_id' => $acc_id))));
        if (count($if_exits_apps) > 0) {

            if ($type == 1) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_app_id' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_app_id']);
                    exit;
                } else {
                    echo 1;
                    exit;
                }
            } else if ($type == 2) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_appopen' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_appopen']);
                    exit;
                } else {
                    echo 2;
                    exit;
                }
            } else if ($type == 3) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_fullad' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_fullad']);
                    exit;
                } else {
                    echo 3;
                    exit;
                }
            } else if ($type == 4) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_fullad_splash' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_fullad_splash']);
                    exit;
                } else {
                    echo 4;
                    exit;
                }
            } else if ($type == 5) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_reward_ad' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_reward_ad']);
                    exit;
                } else {
                    echo 5;
                    exit;
                }
            } else if ($type == 6) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_banner' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_banner']);
                    exit;
                } else {
                    echo 6;
                    exit;
                }
            } else if ($type == 7) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_native' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_native']);
                    exit;
                } else {
                    echo 7;
                    exit;
                }
            } else if ($type == 8) {
                $if_exits = $this->AdsPartnerWises->find('first', array('conditions' =>
                    array('AND' =>
                        array('AdsPartnerWises.app_code' => $app_code),
                        array('AdsPartnerWises.acc_id' => $acc_id),
                        array('AdsPartnerWises.google_native_banner' => $txt_val)
                )));

                if (count($if_exits) > 0) {
                    echo trim($if_exits['AdsPartnerWises']['google_native_banner']);
                    exit;
                } else {
                    echo 8;
                    exit;
                }
            }
        } else {
            echo 'Please choose account and apps';
            exit;
        }

        exit;
    }

}
