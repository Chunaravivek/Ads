<?php
class AppExceptionHandler {
    public static function handle($error) {
       
        echo 'Error This : ' . $error->getMessage();
        // ...
    }
    // ...
}