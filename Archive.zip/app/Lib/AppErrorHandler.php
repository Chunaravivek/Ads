<?php
class AppErrorHandler {
    public static function handleException($error) {
        if ($error instanceof MissingWidgetException) {
           
            return self::handleMissingWidget($error);
        }
        // do other stuff.
    }
}